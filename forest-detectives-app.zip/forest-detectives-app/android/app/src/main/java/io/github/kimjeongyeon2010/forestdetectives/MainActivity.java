package io.github.kimjeongyeon2010.forestdetectives;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
