// Renders the app icon and splash images (1024 icon, 2732 splash) from the game's own fox artwork,
// then @capacitor/assets turns them into every Android/iOS size.  Run: node assets-src/make-assets.js
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');
const root = path.join(__dirname, '..');
const tpl = fs.readFileSync(path.join(root, 'game-src/template.html'), 'utf8');
const fox = tpl.match(/<symbol id="a-fox"[\s\S]*?<\/symbol>/)[0];
const fontsCss = 'file://' + path.join(root, 'www/fonts/fonts.css');
const sprite = `<svg width="0" height="0" style="position:absolute"><defs>${fox}</defs></svg>`;
// magnifier + fox: the "detective" mark used across the icon and splash
const mark = (size, glass = true, ring = '#f6f0d8') => `
  <div style="position:relative;width:${size}px;height:${size}px">
    <svg viewBox="0 0 64 64" style="position:absolute;inset:0;width:100%;height:100%;filter:drop-shadow(0 ${size * 0.025}px ${size * 0.03}px rgba(0,0,0,.22))"><use href="#a-fox"/></svg>
    ${glass ? `<svg viewBox="0 0 100 100" style="position:absolute;right:${-size * 0.12}px;bottom:${-size * 0.1}px;width:${size * 0.52}px;height:${size * 0.52}px">
      <circle cx="40" cy="40" r="26" fill="rgba(255,255,255,.28)" stroke="${ring}" stroke-width="9"/>
      <path d="M59 59 85 85" stroke="${ring}" stroke-width="13" stroke-linecap="round"/>
      <path d="M27 31a16 16 0 0 1 14-10" stroke="#fff" stroke-width="5" stroke-linecap="round" fill="none" opacity=".8"/></svg>` : ''}
  </div>`;
const page = (w, h, body, bg) => `<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="${fontsCss}">
  <style>html,body{margin:0;width:${w}px;height:${h}px;overflow:hidden}body{background:${bg};display:grid;place-items:center;font-family:Jua,sans-serif}</style></head>
  <body>${sprite}${body}</body></html>`;
const green = 'radial-gradient(circle at 30% 25%,#3c8566,#245c47 60%,#1c4a39)';
const jobs = [
  // full icon (iOS + legacy Android): fox on forest green
  ['icon-only.png', 1024, 1024, page(1024, 1024, mark(600), green)],
  // Android adaptive icon: foreground keeps the mark inside the 66% safe zone, background is plain green
  ['icon-foreground.png', 1024, 1024, page(1024, 1024, mark(470), 'transparent')],
  ['icon-background.png', 1024, 1024, page(1024, 1024, '', green)],
  ['splash.png', 2732, 2732, page(2732, 2732, `<div style="display:grid;justify-items:center;gap:90px">${mark(620, true, '#245c47')}<div style="font-size:190px;color:#17382d">숲속 탐정단</div><div style="font-size:84px;color:#6f9a55;margin-top:-60px">누가 먼저 숲속 친구를 찾아낼까요?</div></div>`, '#eef2e4')],
  ['splash-dark.png', 2732, 2732, page(2732, 2732, `<div style="display:grid;justify-items:center;gap:90px">${mark(620)}<div style="font-size:190px;color:#e3ede2">숲속 탐정단</div><div style="font-size:84px;color:#9cc77f;margin-top:-60px">누가 먼저 숲속 친구를 찾아낼까요?</div></div>`, '#0d1915')],
];
(async () => {
  const outDir = path.join(root, 'assets');
  fs.mkdirSync(outDir, { recursive: true });
  const b = await chromium.launch();
  for (const [name, w, h, html] of jobs) {
    const p = await b.newPage({ viewport: { width: w, height: h }, deviceScaleFactor: 1 });
    const file = path.join(__dirname, '_render.html');
    fs.writeFileSync(file, html);
    await p.goto('file://' + file); await p.evaluate(() => document.fonts.ready); await p.waitForTimeout(300);
    await p.screenshot({ path: path.join(outDir, name), omitBackground: name === 'icon-foreground.png' });
    await p.close();
    console.log('rendered', name);
  }
  fs.unlinkSync(path.join(__dirname, '_render.html'));
  await b.close();
})();
