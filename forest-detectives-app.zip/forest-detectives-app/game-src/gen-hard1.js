// Regenerate only the Hard bank as 10x10 with one animal per row/column/region.
const fs = require('fs');
const E = require('./engine.js');
const bank = JSON.parse(fs.readFileSync(__dirname + '/bank.json', 'utf8'));
const rnd = E.mulberry32(707);
const out = [], seen = new Set(), tierSum = [0, 0, 0, 0, 0];
let tries = 0; const t0 = Date.now();
while (out.length < 160 && tries < 20000) {
  tries++;
  const p = E.generate(10, 1, rnd); if (!p) continue;
  const sizes = Array.from({ length: 10 }, (_, x) => p.regions.filter(r => r === x).length);
  const g = new E.Logic(10, 1, p.regions).grade(4);
  if (!(g.solved && g.tiers[4] >= 1 && g.tiers[3] + g.tiers[4] >= 3 && Math.max(...sizes) <= 26)) continue;
  const code = E.encode(E.transformPuzzle(p, 0));
  if (seen.has(code)) continue; seen.add(code);
  out.push(code); g.tiers.forEach((v, i) => tierSum[i] += v);
}
bank.hard = out;
fs.writeFileSync(__dirname + '/bank.json', JSON.stringify(bank));
console.log({ count: out.length, tries, secs: ((Date.now() - t0) / 1000).toFixed(1), avgTiers: tierSum.map(v => (v / out.length).toFixed(1)).join('/') });
// sanity: every stored puzzle decodes to a unique 10x10 one-per-line solution
let bad = 0;
for (const s of out) { const q = E.decode(10, 1, s); const r = E.countSolutions(10, 1, q.regions, 2); if (r.count !== 1 || r.solutions[0].join() !== q.solution.join()) bad++; }
console.log('verify unique:', out.length - bad, '/', out.length);
