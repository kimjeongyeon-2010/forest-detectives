const E = require('./engine.js');
const specs = {
  easy:   { n:7,  k:1, want:160, ok:(g,s)=> g.solved && g.maxTier<=2 && g.tiers[2]>=2 && Math.max(...s)<=14 },
  normal: { n:9,  k:1, want:160, ok:(g,s)=> g.solved && g.maxTier>=3 && (g.tiers[3]+g.tiers[4])>=2 && g.tiers[4]<=3 && Math.min(...s)>=2 && Math.max(...s)<=18 },
  hard:   { n:10, k:2, want:160, ok:(g,s)=> g.solved && g.maxTier>=3 && (g.tiers[3]+g.tiers[4])>=3 && Math.min(...s)>=4 && Math.max(...s)<=20 },
};
const bank = {}, report = {};
for (const [name, sp] of Object.entries(specs)) {
  const rnd = E.mulberry32({easy:101,normal:202,hard:303}[name]);
  const out = [], seen = new Set(); let tries = 0; const t0 = Date.now(); const tierSum=[0,0,0,0,0];
  while (out.length < sp.want && tries < sp.want*40) {
    tries++;
    const p = E.generate(sp.n, sp.k, rnd); if (!p) continue;
    const sizes = Array.from({length:sp.n},(_,x)=>p.regions.filter(r=>r===x).length);
    const g = new E.Logic(sp.n, sp.k, p.regions).grade(4);
    if (!sp.ok(g, sizes)) continue;
    const code = E.encode(E.transformPuzzle(p, 0));
    if (seen.has(code)) continue; seen.add(code);
    out.push(code); g.tiers.forEach((v,i)=>tierSum[i]+=v);
  }
  bank[name] = out;
  report[name] = { count: out.length, tries, secs: ((Date.now()-t0)/1000).toFixed(1), avgTiers: tierSum.map(v=>(v/out.length).toFixed(1)).join('/') };
}
require('fs').writeFileSync('bank.json', JSON.stringify(bank));
console.log(report, 'bytes', JSON.stringify(bank).length);
