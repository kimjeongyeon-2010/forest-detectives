// Firebase pieces the game uses, bundled into the app so login works without loading from a CDN.
import { initializeApp } from 'firebase/app';
import { getAuth, initializeAuth, indexedDBLocalPersistence, browserLocalPersistence, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, deleteUser } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, deleteDoc, serverTimestamp } from 'firebase/firestore/lite';
window.ForestFirebase = {
  app: { initializeApp },
  A: { getAuth, initializeAuth, indexedDBLocalPersistence, browserLocalPersistence, onAuthStateChanged, createUserWithEmailAndPassword, signInWithEmailAndPassword, signOut, deleteUser },
  F: { getFirestore, doc, getDoc, setDoc, deleteDoc, serverTimestamp },
};
