(() => {
'use strict';
const E = window.ForestEngine;
const BANK = /*__BANK__*/null;
const $ = id => document.getElementById(id);
const root = document.documentElement;

/* ---------------- constants ---------------- */
const DIFFS = {
  easy:   { key:'easy',   label:'이지', forest:'새싹 숲',   n:7,  k:1, hearts:5, hints:3, penalty:10, autoAllowed:true,  autoDefault:true,  level:1, letter:'e', spec:'7×7 · 줄마다 1마리',  more:'기회 5 · 힌트 3 · 자동 × 표시' },
  normal: { key:'normal', label:'노멀', forest:'깊은 숲',   n:9,  k:1, hearts:3, hints:2, penalty:20, autoAllowed:true,  autoDefault:false, level:2, letter:'n', spec:'9×9 · 줄마다 1마리',  more:'기회 3 · 힌트 2 · 여러 구역을 묶어 봐야 풀려요' },
  hard:   { key:'hard',   label:'하드', forest:'비밀의 숲', n:10, k:1, hearts:3, hints:1, penalty:30, autoAllowed:false, autoDefault:false, level:3, letter:'h', spec:'10×10 · 줄마다 1마리', more:'기회 3 · 힌트 1 · 가정하고 모순 찾기까지' },
};
const LETTER = { e:'easy', n:'normal', h:'hard' };
const ANIMALS = [ {id:'fox',name:'여우'}, {id:'bear',name:'곰'}, {id:'rabbit',name:'토끼'}, {id:'panda',name:'판다'}, {id:'owl',name:'부엉이'}, {id:'hedgehog',name:'고슴도치'} ];
const REGION_NAMES = ['이끼 언덕','살구 덤불','맑은 연못','라벤더 밭','해바라기 들판','박하 풀숲','들장미 정원','물빛 개울','블루베리 숲','단풍 계곡'];
const PRAISE = ['잘했어요!','멋진 추리예요!','정답이에요!','대단해요! 또 찾았네요!','눈이 정말 밝네요!','척척 찾아내네요!'];
const TIER_LABEL = { 0:'바로잡기', 1:'기본 추리', 2:'한 걸음 추리', 3:'묶어 보기 추리', 4:'가정해 보기' };
const STAGES = /*__STAGES__*/null;
const STAGE_COUNT = STAGES.length;
const CHAPTERS = [
  { no: 1, from: 1,   to: 20,  name: '새싹 길',   tone: 'easy',   hearts: 5, hints: 3, auto: 'on' },
  { no: 2, from: 21,  to: 60,  name: '이끼 언덕', tone: 'easy',   hearts: 5, hints: 3, auto: 'on' },
  { no: 3, from: 61,  to: 120, name: '개울가',    tone: 'easy',   hearts: 5, hints: 3, auto: 'on' },
  { no: 4, from: 121, to: 200, name: '깊은 숲',   tone: 'normal', hearts: 4, hints: 2, auto: 'off' },
  { no: 5, from: 201, to: 300, name: '안개 계곡', tone: 'normal', hearts: 3, hints: 2, auto: 'off' },
  { no: 6, from: 301, to: 400, name: '달빛 숲',   tone: 'hard',   hearts: 3, hints: 1, auto: 'none' },
  { no: 7, from: 401, to: 500, name: '비밀의 숲', tone: 'hard',   hearts: 3, hints: 1, auto: 'none' },
];
const FIREBASE_CONFIG = /*__FIREBASE__*/null;
const FB_VER = '12.19.0';
const chapterOf = N => CHAPTERS.find(c => N >= c.from && N <= c.to) || CHAPTERS[CHAPTERS.length - 1];
const stageSize = N => Math.round(Math.sqrt(STAGES[N - 1].indexOf('|')));
function stageDiff(N) {
  const ch = chapterOf(N), n = stageSize(N);
  return { key: 'stage', tone: ch.tone, label: `스테이지 ${N}`, forest: `${ch.no}장 ${ch.name}`, n, k: 1, hearts: ch.hearts, hints: ch.hints, penalty: 0,
    autoAllowed: ch.auto !== 'none', autoDefault: ch.auto === 'on', stage: N, chapter: ch };
}

/* ---------------- storage ---------------- */
const store = {
  get(k, d) { try { const v = localStorage.getItem('fd2:' + k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('fd2:' + k, JSON.stringify(v)); } catch {} },
};
const settings = {
  name: String(store.get('name', '')).slice(0, 12),
  animal: store.get('animal', 'fox'),
  diff: store.get('diff', 'normal'),
  sfx: store.get('sfx', true) !== false,
  voice: store.get('voice', true) !== false,
  auto: Object.assign({ easy:true, normal:false }, store.get('auto', {})),
  mode: 'mark',
};
if (!ANIMALS.some(a => a.id === settings.animal)) settings.animal = 'fox';
if (!DIFFS[settings.diff]) settings.diff = 'normal';

/* ---------------- helpers ---------------- */
const esc = s => String(s).replace(/[&<>"']/g, ch => ({ '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[ch]));
const fmt = ms => { const s = Math.max(0, Math.floor(ms / 1000)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); };
const svgUse = (id, cls = '') => `<svg class="${cls}" aria-hidden="true"><use href="#${id}"/></svg>`;
let toastTimer;
function toast(text) { const t = $('toast'); t.textContent = text; t.hidden = false; t.style.animation = 'none'; void t.offsetWidth; t.style.animation = ''; clearTimeout(toastTimer); toastTimer = setTimeout(() => { t.hidden = true; }, 3800); }
const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)');

/* ---------------- puzzles ---------------- */
function pickPid(diff, rnd = Math.random) {
  const d = DIFFS[diff], list = BANK[diff];
  const recent = store.get('recent-' + diff, []);
  let idx = 0;
  for (let tries = 0; tries < 30; tries++) { idx = Math.floor(rnd() * list.length); if (!recent.includes(idx)) break; }
  if (G === null || !G.multi) store.set('recent-' + diff, [idx].concat(recent).slice(0, 40));
  return `${d.letter}${idx}.${Math.floor(rnd() * 8)}.${Math.floor(rnd() * 100000)}`;
}
function parsePid(pid) {
  const m = /^([enh])(\d{1,4})\.([0-7])\.(\d{1,6})$/.exec(String(pid || ''));
  if (!m) return null;
  const diff = LETTER[m[1]];
  return { diff, idx: Number(m[2]) % BANK[diff].length, t: Number(m[3]), seed: Number(m[4]) };
}
function buildPuzzle(pid) {
  const sm = /^s(\d{1,3})$/.exec(String(pid || ''));
  if (sm) {
    const N = Number(sm[1]); if (N < 1 || N > STAGE_COUNT) return null;
    const n = stageSize(N), q = E.decode(n, 1, STAGES[N - 1]);
    const palette = E.shuffle([0,1,2,3,4,5,6,7,8,9], E.mulberry32(N * 7919 + 17)).slice(0, n);
    return { pid, diff: 'stage', stage: N, n, k: 1, regions: q.regions, solution: q.solution, sol: new Set(q.solution), palette, label: `스테이지 ${N}` };
  }
  const p = parsePid(pid); if (!p) return null;
  const d = DIFFS[p.diff];
  const q = E.transformPuzzle(E.decode(d.n, d.k, BANK[p.diff][p.idx]), p.t);
  const rnd = E.mulberry32(p.seed * 7919 + p.idx * 31 + p.t);
  const palette = E.shuffle([0,1,2,3,4,5,6,7,8,9], rnd).slice(0, d.n);
  return { pid, diff: p.diff, n: d.n, k: d.k, regions: q.regions, solution: q.solution, sol: new Set(q.solution), palette,
    label: `${d.letter.toUpperCase()}${String(p.idx + 1).padStart(3, '0')}-${p.t + 1}` };
}

/* ---------------- native app bridge (Capacitor; inactive on the website) ---------------- */
const SITE_URL = 'https://kimjeongyeon-2010.github.io/forest-detectives/';
const Native = {
  is() { const c = window.Capacitor; return !!(c && typeof c.isNativePlatform === 'function' && c.isNativePlatform()); },
  plugin(name) { const c = window.Capacitor; return this.is() && c.Plugins ? c.Plugins[name] || null : null; },
  haptic(kind) {
    const h = this.plugin('Haptics'); if (!h) return;
    try {
      if (kind === 'found') h.impact({ style: 'LIGHT' });
      else if (kind === 'wrong') h.notification({ type: 'ERROR' });
      else if (kind === 'win') h.notification({ type: 'SUCCESS' });
    } catch {}
  },
};
function initNative() {
  if (!Native.is()) return;
  root.classList.add('native');
  const App = Native.plugin('App');
  if (App) App.addListener('backButton', () => {
    const open = [...document.querySelectorAll('dialog')].find(d => d.open);
    if (open) { open.close(); return; }
    if (!$('play').hidden) { $('leaveBtn').click(); return; }
    if (!$('stages').hidden) { goHome(); return; }
    if (App.minimizeApp) App.minimizeApp().catch(() => {}); else App.exitApp();
  });
  const splash = Native.plugin('SplashScreen');
  if (splash) setTimeout(() => splash.hide().catch(() => {}), 250);
}

/* ---------------- audio ---------------- */
const Sfx = {
  ctx: null,
  ensure() {
    if (!this.ctx) { try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch { this.ctx = null; } }
    if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
    return this.ctx;
  },
  tone(f, t0, dur, type, gain, slideTo) {
    const c = this.ctx, o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(f, t0);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t0 + dur);
    g.gain.setValueAtTime(0.0001, t0); g.gain.exponentialRampToValueAtTime(gain, t0 + 0.015); g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g).connect(c.destination); o.start(t0); o.stop(t0 + dur + 0.05);
  },
  play(name) {
    if (!settings.sfx) return;
    const c = this.ensure(); if (!c) return;
    const t = c.currentTime + 0.01;
    try {
      if (name === 'mark') this.tone(1250, t, 0.05, 'triangle', 0.03);
      else if (name === 'found') [659.25, 830.61, 987.77].forEach((f, i) => { this.tone(f, t + i * 0.075, 0.4, 'sine', 0.15); this.tone(f * 2, t + i * 0.075, 0.18, 'triangle', 0.03); });
      else if (name === 'wrong') { this.tone(196, t, 0.32, 'triangle', 0.2, 98); this.tone(150, t + 0.05, 0.25, 'sine', 0.12, 80); }
      else if (name === 'win') [523.25, 659.25, 783.99, 1046.5, 783.99, 1046.5, 1318.5].forEach((f, i) => this.tone(f, t + i * 0.11, 0.55, 'triangle', 0.11));
      else if (name === 'tick') this.tone(587.33, t, 0.14, 'sine', 0.12);
      else if (name === 'go') { this.tone(880, t, 0.3, 'sine', 0.14); this.tone(1318.5, t + 0.08, 0.35, 'sine', 0.08); }
      else if (name === 'hint') [783.99, 1174.66].forEach((f, i) => this.tone(f, t + i * 0.09, 0.3, 'sine', 0.09));
      else if (name === 'lose') [392, 329.63, 261.63].forEach((f, i) => this.tone(f, t + i * 0.18, 0.5, 'triangle', 0.12));
      else if (name === 'other') this.tone(1046.5, t, 0.2, 'sine', 0.05);
    } catch {}
  },
};
function speak(text) {
  if (!settings.voice) return;
  const tts = Native.plugin('TextToSpeech');
  if (tts) { tts.stop().catch(() => {}).then(() => tts.speak({ text, lang: 'ko-KR', rate: 1.0, pitch: 1.1, volume: 0.9, category: 'ambient' })).catch(() => {}); return; }
  if (!('speechSynthesis' in window) || !('SpeechSynthesisUtterance' in window)) return;
  try {
    const s = window.speechSynthesis; s.cancel();
    const u = new SpeechSynthesisUtterance(text), voices = s.getVoices();
    const ko = voices.find(v => /^ko/i.test(v.lang) && v.localService) || voices.find(v => /^ko/i.test(v.lang));
    if (ko) u.voice = ko;
    u.lang = 'ko-KR'; u.rate = 1.05; u.pitch = 1.12; u.volume = 0.85;
    s.speak(u);
  } catch {}
}
document.addEventListener('pointerdown', () => { Sfx.ensure(); try { window.speechSynthesis && window.speechSynthesis.getVoices(); } catch {} }, { once: true });

/* ---------------- ambient background ---------------- */
const Ambient = {
  cv: $('ambient'), ctx: null, parts: [], stars: [], w: 0, h: 0, dark: false, raf: 0, frame: 0,
  init() {
    this.ctx = this.cv.getContext('2d');
    const mq = matchMedia('(prefers-color-scheme: dark)');
    const theme = () => { const t = root.getAttribute('data-theme'); const d = t ? t === 'dark' : mq.matches; if (d !== this.dark) { this.dark = d; this.seed(); } };
    this.dark = !this.dark; theme();
    mq.addEventListener && mq.addEventListener('change', theme);
    new MutationObserver(theme).observe(root, { attributes: true, attributeFilter: ['data-theme'] });
    addEventListener('resize', () => { this.resize(); if (reduceMotion.matches) this.draw(); });
    document.addEventListener('visibilitychange', () => this.run());
    reduceMotion.addEventListener && reduceMotion.addEventListener('change', () => this.run());
    this.resize(); this.run();
  },
  resize() {
    const dpr = Math.min(1.5, window.devicePixelRatio || 1);
    this.w = innerWidth; this.h = innerHeight;
    this.cv.width = Math.round(this.w * dpr); this.cv.height = Math.round(this.h * dpr);
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  },
  seed() {
    const small = innerWidth < 700, R = Math.random;
    this.parts = []; this.stars = [];
    if (this.dark) {
      for (let i = 0; i < (small ? 16 : 30); i++) this.parts.push({ x: R(), y: 0.25 + R() * 0.75, vx: (R() - 0.5) * 0.0006, vy: (R() - 0.5) * 0.0005, ph: R() * 6.28, sp: 0.02 + R() * 0.03, r: 1.4 + R() * 1.4, warm: R() < 0.3 });
      for (let i = 0; i < (small ? 40 : 80); i++) this.stars.push({ x: R(), y: R() * 0.45, r: 0.4 + R() * 0.9, a: 0.15 + R() * 0.4 });
    } else {
      const cols = ['#9cc27d', '#bcd894', '#f2b48f', '#e9cf7a', '#f4abb9'];
      for (let i = 0; i < (small ? 9 : 16); i++) this.parts.push({ x: R(), y: R(), vx: 0, vy: 0.00025 + R() * 0.0004, ph: R() * 6.28, rot: R() * 6.28, vr: (R() - 0.5) * 0.02, s: 4 + R() * 5, c: cols[i % cols.length] });
    }
    if (reduceMotion.matches) this.draw();
  },
  draw() {
    const c = this.ctx, w = this.w, h = this.h; c.clearRect(0, 0, w, h);
    if (this.dark) {
      for (const s of this.stars) { c.globalAlpha = s.a; c.fillStyle = '#e8f2d8'; c.beginPath(); c.arc(s.x * w, s.y * h, s.r, 0, 6.28); c.fill(); }
      for (const p of this.parts) {
        const a = 0.25 + 0.75 * Math.max(0, Math.sin(p.ph)), x = p.x * w, y = p.y * h;
        const g = c.createRadialGradient(x, y, 0, x, y, p.r * 8);
        const col = p.warm ? '255,214,140' : '214,240,140';
        g.addColorStop(0, `rgba(${col},${0.55 * a})`); g.addColorStop(1, `rgba(${col},0)`);
        c.globalAlpha = 1; c.fillStyle = g; c.beginPath(); c.arc(x, y, p.r * 8, 0, 6.28); c.fill();
        c.fillStyle = `rgba(${col},${0.9 * a})`; c.beginPath(); c.arc(x, y, p.r, 0, 6.28); c.fill();
      }
    } else {
      for (const p of this.parts) {
        c.save(); c.globalAlpha = 0.42; c.fillStyle = p.c; c.translate(p.x * w + Math.sin(p.ph) * 18, p.y * h); c.rotate(p.rot);
        c.beginPath(); c.ellipse(0, 0, p.s, p.s * 0.45, 0, 0, 6.28); c.fill(); c.restore();
      }
    }
    c.globalAlpha = 1;
  },
  step() {
    for (const p of this.parts) {
      if (this.dark) {
        p.ph += p.sp; p.x += p.vx + Math.sin(p.ph * 0.5) * 0.0002; p.y += p.vy + Math.cos(p.ph * 0.4) * 0.0002;
        if (p.x < -0.05) p.x = 1.05; if (p.x > 1.05) p.x = -0.05; if (p.y < 0.2) p.vy = Math.abs(p.vy); if (p.y > 1.02) p.vy = -Math.abs(p.vy);
      } else {
        p.ph += 0.02; p.y += p.vy; p.rot += p.vr; if (p.y > 1.05) { p.y = -0.05; p.x = Math.random(); }
      }
    }
  },
  run() {
    cancelAnimationFrame(this.raf);
    if (reduceMotion.matches || document.hidden) { this.draw(); return; }
    const loop = () => { this.frame++; if (this.frame % 2 === 0) { this.step(); this.draw(); } this.raf = requestAnimationFrame(loop); };
    this.raf = requestAnimationFrame(loop);
  },
};

/* ---------------- particles over the board ---------------- */
const FX = {
  cv: $('fx'), ctx: null, parts: [], raf: 0,
  resize() {
    const r = this.cv.getBoundingClientRect(), dpr = Math.min(2, window.devicePixelRatio || 1);
    this.cv.width = Math.round(r.width * dpr); this.cv.height = Math.round(r.height * dpr);
    this.ctx = this.cv.getContext('2d'); this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  },
  at(cell) {
    const el = cellEls[cell]; if (!el) return null;
    const a = el.getBoundingClientRect(), b = this.cv.getBoundingClientRect();
    return { x: a.left - b.left + a.width / 2, y: a.top - b.top + a.height / 2, s: a.width };
  },
  burst(cell, kind) {
    if (reduceMotion.matches) return;
    const p = this.at(cell); if (!p) return;
    this.resize();
    const R = Math.random;
    const cols = kind === 'wrong' ? ['#c4513a', '#8e6c53', '#e08a6e'] : ['#8cc06c', '#f0bf3a', '#f28a46', '#f4abb9', '#9cc7f0', '#6fae52'];
    const count = kind === 'wrong' ? 10 : 22;
    for (let i = 0; i < count; i++) {
      const a = R() * 6.28, v = (kind === 'wrong' ? 1.5 : 2.2) + R() * 3;
      this.parts.push({ x: p.x, y: p.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - (kind === 'wrong' ? 0 : 1.5), g: 0.12, life: 0, max: 40 + R() * 25,
        size: (kind === 'wrong' ? 2.5 : 3.5) + R() * 3.5, rot: R() * 6.28, vr: (R() - 0.5) * 0.3, shape: kind === 'wrong' ? 'dot' : (i % 3 === 0 ? 'spark' : 'leaf'), c: cols[i % cols.length] });
    }
    this.go();
  },
  confetti() {
    if (reduceMotion.matches) return;
    this.resize();
    const w = this.cv.getBoundingClientRect().width, R = Math.random;
    const cols = ['#8cc06c', '#f0bf3a', '#f28a46', '#f4abb9', '#9cc7f0', '#c3b2e8', '#6fae52'];
    for (let i = 0; i < 110; i++) this.parts.push({ x: R() * w, y: -10 - R() * 120, vx: (R() - 0.5) * 1.6, vy: 1 + R() * 2.5, g: 0.035, life: 0, max: 150 + R() * 80, size: 4 + R() * 5, rot: R() * 6.28, vr: (R() - 0.5) * 0.2, shape: i % 4 === 0 ? 'spark' : 'leaf', c: cols[i % cols.length], sway: R() * 6.28 });
    this.go();
  },
  go() {
    if (this.raf) return;
    const loop = () => {
      const c = this.ctx, b = this.cv.getBoundingClientRect();
      c.clearRect(0, 0, b.width, b.height);
      this.parts = this.parts.filter(p => p.life < p.max);
      for (const p of this.parts) {
        p.life++; p.vy += p.g; p.x += p.vx + (p.sway !== undefined ? Math.sin(p.life * 0.05 + p.sway) * 0.6 : 0); p.y += p.vy; p.vx *= 0.985; p.rot += p.vr;
        const a = Math.min(1, (p.max - p.life) / 20);
        c.save(); c.globalAlpha = a; c.translate(p.x, p.y); c.rotate(p.rot); c.fillStyle = p.c;
        if (p.shape === 'leaf') { c.beginPath(); c.ellipse(0, 0, p.size, p.size * 0.45, 0, 0, 6.28); c.fill(); }
        else if (p.shape === 'spark') { const s = p.size; c.beginPath(); c.moveTo(0, -s); c.lineTo(s * 0.25, -s * 0.25); c.lineTo(s, 0); c.lineTo(s * 0.25, s * 0.25); c.lineTo(0, s); c.lineTo(-s * 0.25, s * 0.25); c.lineTo(-s, 0); c.lineTo(-s * 0.25, -s * 0.25); c.closePath(); c.fill(); }
        else { c.beginPath(); c.arc(0, 0, p.size * 0.6, 0, 6.28); c.fill(); }
        c.restore();
      }
      if (this.parts.length) this.raf = requestAnimationFrame(loop); else { this.raf = 0; c.clearRect(0, 0, b.width, b.height); }
    };
    this.raf = requestAnimationFrame(loop);
  },
  clear() { this.parts = []; },
};

/* ---------------- board building ---------------- */
let cellEls = [];
function cellMarkup(P, i, opts) {
  const n = P.n, g = P.regions[i], r = (i / n) | 0, c = i % n, pal = P.palette[g];
  // every cell is its own tile with the same thin line on all four sides; regions are told apart by colour only
  const clip = 'inset(1px round 3px)';
  const cls = ['cell'];
  const extra = opts && opts.animal ? `<svg class="ani" aria-hidden="true"><use href="#a-${opts.animal}"/></svg>` : '';
  const tag = opts && opts.static ? 'span' : 'button';
  return `<${tag} class="${cls.join(' ')}" style="--r:${r};--c:${c}" data-i="${i}"${tag === 'button' ? ' type="button" tabindex="-1"' : ''}>` +
    `<span class="patch" style="--rc:var(--r${pal});clip-path:${clip}"></span>` +
    `<svg class="x" aria-hidden="true"><use href="#i-x"/></svg>${extra}</${tag}>`;
}
function buildBoard() {
  const P = G.P, grid = $('grid');
  grid.style.setProperty('--n', P.n);
  grid.setAttribute('role', 'group');
  grid.setAttribute('aria-label', `${P.n}×${P.n} 퍼즐 보드`);
  grid.innerHTML = P.regions.map((_, i) => cellMarkup(P, i, { animal: G.animal })).join('');
  cellEls = Array.from(grid.children);
  focusIdx = Math.min(focusIdx, P.n * P.n - 1);
  cellEls[focusIdx].tabIndex = 0;
  renderBoardState();
}
function cellState(i) {
  if (G.found.has(i)) return 'found';
  if (G.wrong.has(i)) return 'wrong';
  const m = G.marks.get(i);
  return m === 'x' ? 'x' : m === 'auto' ? 'auto' : 'empty';
}
function renderBoardState() {
  if (!G) return;
  const P = G.P, n = P.n, reveal = G.reveal;
  for (let i = 0; i < cellEls.length; i++) {
    const el = cellEls[i], s = cellState(i);
    el.classList.toggle('found', s === 'found');
    el.classList.toggle('wrong', s === 'wrong');
    el.classList.toggle('marked', s === 'x' || s === 'auto');
    el.classList.toggle('auto', s === 'auto');
    el.classList.toggle('reveal', !!reveal && s !== 'found' && P.sol.has(i));
    const word = s === 'found' ? '친구 발견' : s === 'wrong' ? '친구 없음(확인됨)' : s === 'empty' ? '빈 칸' : '× 표시';
    el.setAttribute('aria-label', `${((i / n) | 0) + 1}행 ${(i % n) + 1}열, ${REGION_NAMES[P.palette[P.regions[i]]]}, ${word}`);
  }
}

/* ---------------- game state ---------------- */
let G = null;
let focusIdx = 0;
let countdownTimer = 0;
function newGame(pid, opts) {
  const P = buildPuzzle(pid);
  if (!P) { toast('퍼즐을 불러오지 못했어요.'); return; }
  const d = P.stage ? stageDiff(P.stage) : DIFFS[P.diff];
  const autoKey = P.stage ? 'ch' + d.chapter.no : P.diff;
  clearTimeout(countdownTimer);
  FX.clear();
  G = { P, d, multi: !!opts.multi, spectate: !!opts.spectate, animal: settings.animal,
    found: new Set(), marks: new Map(), wrong: new Set(), mistakes: 0, hintsUsed: 0, undo: [],
    status: opts.spectate ? 'spectate' : 'countdown', startAt: 0, endAt: 0, logic: null, hint: null, reveal: false,
    auto: d.autoAllowed && (settings.auto[autoKey] !== undefined ? !!settings.auto[autoKey] : d.autoDefault), autoKey, newBest: false, quitArm: 0, stars: 0, stageResult: null };
  focusIdx = 0;
  showScreen('play');
  renderPlayChrome();
  buildBoard();
  renderStatus();
  hideHint();
  $('result').hidden = true;
  $('spectate').hidden = !G.spectate;
  if (G.spectate) { $('countdown').hidden = true; return; }
  startCountdown();
}
function startCountdown() {
  const ov = $('countdown'), num = $('countNum');
  let k = 3;
  const tick = () => {
    if (!G || G.status !== 'countdown') return;
    if (k > 0) { ov.hidden = false; num.textContent = k; num.style.animation = 'none'; void num.offsetWidth; num.style.animation = ''; Sfx.play('tick'); k--; countdownTimer = setTimeout(tick, 800); }
    else {
      num.textContent = '시작!'; num.style.animation = 'none'; void num.offsetWidth; num.style.animation = ''; Sfx.play('go');
      G.status = 'playing'; G.startAt = performance.now();
      countdownTimer = setTimeout(() => { ov.hidden = true; }, 450);
      renderStatus(); Net.report();
      if (cellEls[focusIdx] && document.activeElement === document.body) {}
    }
  };
  tick();
}
const canPlay = () => !!G && G.status === 'playing';
function elapsed() { if (!G || !G.startAt) return 0; return (G.endAt || performance.now()) - G.startAt; }
function penaltyMs() { return G && G.multi ? G.hintsUsed * G.d.penalty * 1000 : 0; }

function setMark(i, val, batch) {
  const prev = G.marks.get(i);
  if (prev === val) return;
  if (val) G.marks.set(i, val); else G.marks.delete(i);
  if (batch) batch.push({ i, prev });
}
function toggleMark(i) {
  if (G.found.has(i) || G.wrong.has(i)) return null;
  const batch = [];
  setMark(i, G.marks.has(i) ? null : 'x', batch);
  Sfx.play('mark');
  renderBoardState();
  return batch;
}
function pushUndo(batch) { if (batch && batch.length) { G.undo.push(batch); if (G.undo.length > 300) G.undo.shift(); } }
function undo() {
  if (!canPlay()) return;
  const batch = G.undo.pop();
  if (!batch) { toast('되돌릴 표시가 없어요.'); return; }
  for (let j = batch.length - 1; j >= 0; j--) { const { i, prev } = batch[j]; if (G.found.has(i) || G.wrong.has(i)) continue; if (prev) G.marks.set(i, prev); else G.marks.delete(i); }
  renderBoardState();
}
function autoMarkAround(cell) {
  const P = G.P, n = P.n, Gm = E.geom(n, P.regions);
  const cells = new Set(Gm.nbrs[cell]);
  for (const u of Gm.cellUnits[cell]) {
    const unit = Gm.unitCells[u];
    if (unit.filter(x => G.found.has(x)).length >= P.k) unit.forEach(x => cells.add(x));
  }
  for (const x of cells) if (!G.found.has(x) && !G.wrong.has(x) && !G.marks.has(x)) G.marks.set(x, 'auto');
}
function guess(i) {
  if (!canPlay() || G.found.has(i) || G.wrong.has(i)) return;
  hideHint();
  const P = G.P;
  if (P.sol.has(i)) {
    G.found.add(i); G.marks.delete(i);
    if (G.auto) autoMarkAround(i);
    renderBoardState(); renderStatus();
    Sfx.play('found'); FX.burst(i, 'found'); Native.haptic('found');
    if (G.found.size === P.solution.length) { win(); return; }
    speak(PRAISE[(G.found.size - 1) % PRAISE.length]);
  } else {
    G.mistakes++; G.wrong.add(i); G.marks.delete(i);
    renderBoardState(); renderStatus(true);
    Sfx.play('wrong'); FX.burst(i, 'wrong'); Native.haptic('wrong');
    const el = cellEls[i]; el.classList.remove('shake'); void el.offsetWidth; el.classList.add('shake');
    const left = G.d.hearts - G.mistakes;
    if (left <= 0) { lose(); return; }
    toast(`여기엔 친구가 없어요. 남은 기회 ${left}번`);
  }
  Net.report();
}
function win() {
  G.status = 'won'; G.endAt = performance.now();
  Sfx.play('win'); FX.confetti(); Native.haptic('win');
  speak('대단해요! 모든 친구를 찾았어요!');
  G.P.solution.forEach((c, j) => setTimeout(() => { const el = cellEls[c]; if (el) { el.classList.remove('cheer'); void el.offsetWidth; el.classList.add('cheer'); } }, j * 70));
  if (!G.multi) recordSolo(true);
  renderStatus(); Net.report(); renderResult();
}
function lose(gaveUp) {
  G.status = gaveUp ? 'gaveup' : 'lost'; G.endAt = performance.now();
  Sfx.play('lose');
  if (!G.multi) { G.reveal = true; recordSolo(false); }
  renderBoardState(); renderStatus(); Net.report(); renderResult();
}

/* ---------------- input ---------------- */
let stroke = null, lastTap = null;
function cellAt(x, y) {
  const grid = $('grid'), r = grid.getBoundingClientRect(), n = G.P.n;
  if (x < r.left || x >= r.right || y < r.top || y >= r.bottom) return -1;
  const c = Math.floor((x - r.left) / r.width * n), rr = Math.floor((y - r.top) / r.height * n);
  return Math.min(n - 1, rr) * n + Math.min(n - 1, c);
}
function paint(i) {
  if (i < 0 || stroke.seen.has(i)) return;
  stroke.seen.add(i);
  if (G.found.has(i) || G.wrong.has(i)) return;
  const want = stroke.mode === 'add' ? 'x' : null;
  const cur = G.marks.get(i);
  if (stroke.mode === 'add' && cur) return;
  if (stroke.mode === 'erase' && !cur) return;
  setMark(i, want, stroke.batch);
  renderBoardState();
}
function initInput() {
  const grid = $('grid');
  grid.addEventListener('pointerdown', e => {
    if (!canPlay() || (e.pointerType === 'mouse' && e.button !== 0)) return;
    const i = cellAt(e.clientX, e.clientY); if (i < 0) return;
    e.preventDefault();
    try { grid.setPointerCapture(e.pointerId); } catch {}
    setFocus(i, false);
    stroke = { id: e.pointerId, start: i, x: e.clientX, y: e.clientY, lx: e.clientX, ly: e.clientY, moved: false, mode: null, seen: new Set(), batch: [] };
  });
  grid.addEventListener('pointermove', e => {
    if (!stroke || e.pointerId !== stroke.id) return;
    if (!canPlay()) { stroke = null; return; }
    if (!stroke.moved) {
      if (Math.hypot(e.clientX - stroke.x, e.clientY - stroke.y) < 9) return;
      stroke.moved = true; lastTap = null;
      stroke.mode = G.marks.has(stroke.start) ? 'erase' : 'add';
      paint(stroke.start);
    }
    const r = grid.getBoundingClientRect(), step = Math.max(2, r.width / G.P.n / 3);
    const dist = Math.hypot(e.clientX - stroke.lx, e.clientY - stroke.ly), k = Math.max(1, Math.ceil(dist / step));
    for (let s = 1; s <= k; s++) paint(cellAt(stroke.lx + (e.clientX - stroke.lx) * s / k, stroke.ly + (e.clientY - stroke.ly) * s / k));
    stroke.lx = e.clientX; stroke.ly = e.clientY;
  });
  const end = e => {
    if (!stroke || (e && e.pointerId !== stroke.id)) return;
    const s = stroke; stroke = null;
    if (s.moved) { pushUndo(s.batch); if (s.batch.length) Sfx.play('mark'); return; }
    if (e && e.type === 'pointerup') tap(s.start);
  };
  grid.addEventListener('pointerup', end);
  grid.addEventListener('pointercancel', end);
  grid.addEventListener('lostpointercapture', e => { if (stroke && stroke.moved) end(e); });
  grid.addEventListener('contextmenu', e => e.preventDefault());
  grid.addEventListener('keydown', e => {
    if (!G || G.spectate) return;
    const n = G.P.n, r = (focusIdx / n) | 0, c = focusIdx % n;
    const moves = { ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1] };
    if (moves[e.key]) { e.preventDefault(); const [dr, dc] = moves[e.key]; setFocus(Math.max(0, Math.min(n - 1, r + dr)) * n + Math.max(0, Math.min(n - 1, c + dc)), true); return; }
    if (e.key === ' ' || e.key === 'x' || e.key === 'X') { e.preventDefault(); if (canPlay() && !e.repeat) pushUndo(toggleMark(focusIdx)); return; }
    if (e.key === 'Enter' || e.key === 'f' || e.key === 'F') { e.preventDefault(); if (!e.repeat) guess(focusIdx); return; }
  });
  grid.addEventListener('keyup', e => { if (e.key === ' ') e.preventDefault(); });
  document.addEventListener('keydown', e => {
    if (!G || $('play').hidden || e.target.matches('input,textarea')) return;
    if ((e.key === 'z' || e.key === 'Z') && !e.altKey) { if (e.ctrlKey || e.metaKey || e.target.closest('#grid')) { e.preventDefault(); undo(); } }
  });
}
function setFocus(i, move) {
  if (cellEls[focusIdx]) cellEls[focusIdx].tabIndex = -1;
  focusIdx = i;
  const el = cellEls[i]; if (!el) return;
  el.tabIndex = 0;
  if (move) el.focus(); else el.focus({ preventScroll: true });
}
function tap(i) {
  const now = performance.now();
  if (settings.mode === 'find') { guess(i); return; }
  if (lastTap && lastTap.i === i && now - lastTap.time < 380) {
    const b = lastTap.batch;
    if (b) { for (const { i: c, prev } of b) { if (prev) G.marks.set(c, prev); else G.marks.delete(c); } const top = G.undo[G.undo.length - 1]; if (top === b) G.undo.pop(); }
    lastTap = null; renderBoardState(); guess(i); return;
  }
  const batch = toggleMark(i);
  pushUndo(batch);
  lastTap = { i, time: now, batch };
}

/* ---------------- hints ---------------- */
function unitName(u) {
  const n = G.P.n;
  if (u < n) return `${u + 1}번째 가로줄`;
  if (u < 2 * n) return `${u - n + 1}번째 세로줄`;
  return `‘${REGION_NAMES[G.P.palette[u - 2 * n]]}’ 구역`;
}
function typeWord(u) { const n = G.P.n; return u < n ? '가로줄' : u < 2 * n ? '세로줄' : '구역'; }
function listNames(us) { return us.map(unitName).join(', '); }
function computeHint() {
  const P = G.P, n = P.n;
  const L = G.logic || (G.logic = new E.Logic(n, P.k, P.regions));
  const bad = [...G.marks.keys()].filter(c => P.sol.has(c));
  if (bad.length) return { tier: 0, units: [], targets: bad, text: `× 표시 중에 잘못된 곳이 ${bad.length}칸 있어요. 반짝이는 칸에는 사실 친구가 숨어 있어요.`, unmark: bad };
  const st = new Int8Array(n * n);
  for (const c of G.marks.keys()) st[c] = 2;
  for (const c of G.wrong) st[c] = 2;
  for (const c of G.found) st[c] = 1;
  const first = L.tier1(st);
  if (first && first.elim.length) {
    const t = Int8Array.from(st), all = new Set();
    let s = first;
    while (s && s.elim.length) { s.elim.forEach(c => { all.add(c); t[c] = 2; }); s = L.tier1(t); }
    return { tier: 1, units: [], targets: [...all], mark: [...all], text: `찾은 친구의 주변 8칸, 그리고 친구가 다 채워진 줄과 구역의 남은 칸은 모두 비어 있어요. 먼저 ${all.size}칸을 ×로 정리해 볼까요?` };
  }
  const s = first || L.next(st, 4);
  if (!s) {
    const c = P.solution.find(x => !G.found.has(x));
    return { tier: 0, units: [], targets: [c], text: '여기에 친구가 숨어 있어요. 두 번 탭해서 찾아보세요.' };
  }
  const u0 = s.units && s.units[0];
  const need = u0 !== undefined ? L.need(st, u0) : 1;
  let text = '';
  if (s.kind === 'last') text = `${unitName(u0)}에서 친구가 들어갈 수 있는 칸은 ${s.place.length === 1 ? '이 한 칸뿐' : `딱 ${s.place.length}칸뿐`}이에요. 반짝이는 칸을 두 번 탭해 보세요.`;
  else if (s.kind === 'pack' && s.place.length) text = `${unitName(u0)}에는 친구 ${need}마리가 더 필요해요. 서로 붙지 않게 놓는 방법은 모두 반짝이는 칸을 써요. 여기엔 꼭 친구가 있어요.`;
  else if (s.kind === 'pack') text = `${unitName(u0)}에 친구 ${need}마리를 서로 붙지 않게 놓는 방법 중에 반짝이는 칸을 쓰는 경우는 없어요.`;
  else if (s.kind === 'confine' && s.units.length === 1) text = `${unitName(u0)}의 남은 후보 칸이 모두 ${unitName(s.via[0])} 안에 있어요. 그래서 ${unitName(s.via[0])}의 친구는 ${unitName(u0)}에서 나오고, ${unitName(s.via[0])}의 나머지 칸은 비어 있어요.`;
  else if (s.kind === 'confine') text = `${listNames(s.units)}의 후보 칸이 모두 ${listNames(s.via)} 안에 모여 있어요. 이 ${s.via.length}개 ${typeWord(s.via[0])}에 들어갈 친구가 전부 이 ${typeWord(u0)}들 몫이라, 나머지 칸은 비어 있어요.`;
  else if (s.kind === 'blocks') text = `반짝이는 칸에 친구를 두면 ${unitName(u0)}에 친구를 놓을 자리가 모자라요. 그러니 이 칸은 비어 있어요.`;
  else if (s.kind === 'trial') text = `반짝이는 칸에 친구가 있다고 가정하고 차근차근 따라가 보면 ${u0 !== undefined ? unitName(u0) + '에서' : '이웃한 친구끼리'} 모순이 생겨요. 그러니 이 칸은 비어 있어요.`;
  else text = '반짝이는 칸을 살펴보세요.';
  const units = [...(s.units || []), ...(s.via || [])];
  const targets = s.place.length ? s.place : s.elim;
  return { tier: s.tier, units, targets, text, mark: s.place.length ? null : s.elim };
}
function hintsLeft() { return G ? G.d.hints - G.hintsUsed : 0; }
function requestHint() {
  if (!canPlay()) return;
  if (hintsLeft() <= 0) { toast('이번 판의 힌트를 모두 썼어요.'); return; }
  const h = computeHint(); if (!h) return;
  G.hintsUsed++;
  Sfx.play('hint');
  showHint(h);
  renderStatus(); Net.report();
  if (G.multi) toast(`힌트를 써서 기록에 ${G.d.penalty}초가 더해져요.`);
}
function showHint(h) {
  G.hint = h;
  const Gm = E.geom(G.P.n, G.P.regions);
  cellEls.forEach(el => el.classList.remove('h-unit', 'h-target'));
  for (const u of h.units) for (const c of Gm.unitCells[u]) cellEls[c].classList.add('h-unit');
  for (const c of h.targets) cellEls[c].classList.add('h-target');
  $('hintTier').textContent = `힌트 · ${TIER_LABEL[h.tier] || ''}`;
  $('hintText').textContent = h.text;
  const acts = $('hintActions'); acts.innerHTML = '';
  if (h.mark && h.mark.length) acts.append(button('×로 표시하기', 'btn btn-primary', () => { const b = []; h.mark.forEach(c => { if (!G.found.has(c) && !G.wrong.has(c) && G.marks.get(c) !== 'x') setMark(c, 'x', b); }); pushUndo(b); hideHint(); renderBoardState(); Sfx.play('mark'); }));
  if (h.unmark && h.unmark.length) acts.append(button('잘못된 × 지우기', 'btn btn-primary', () => { const b = []; h.unmark.forEach(c => setMark(c, null, b)); pushUndo(b); hideHint(); renderBoardState(); }));
  acts.append(button('닫기', 'btn btn-ghost', hideHint));
  $('hintBox').hidden = false;
}
function hideHint() {
  if (G) G.hint = null;
  cellEls.forEach(el => el.classList.remove('h-unit', 'h-target'));
  $('hintBox').hidden = true;
}
function button(label, cls, fn, id) { const b = document.createElement('button'); b.type = 'button'; b.className = cls; b.innerHTML = label; if (id) b.id = id; b.addEventListener('click', fn); return b; }

/* ---------------- records ---------------- */
function starsFor(g) { return g.mistakes === 0 && g.hintsUsed === 0 ? 3 : g.mistakes + g.hintsUsed <= 2 ? 2 : 1; }
function recordSolo(won) {
  if (G.P.stage) {
    if (won) { G.stars = starsFor(G); G.stageResult = Progress.record(G.P.stage, G.stars, Math.round(elapsed())); }
    renderRecords();
    return;
  }
  const rec = store.get('records', {});
  const r = rec[G.P.diff] || { best: 0, wins: 0, plays: 0 };
  r.plays++;
  if (won) { r.wins++; const t = Math.round(elapsed()); if (!r.best || t < r.best) { r.best = t; G.newBest = true; } }
  rec[G.P.diff] = r; store.set('records', rec);
  renderRecords();
}
function renderRecords() {
  const S = Progress.data.stages;
  $('records').innerHTML = CHAPTERS.map(ch => {
    const total = ch.to - ch.from + 1; let done = 0, stars = 0;
    for (let i = ch.from; i <= ch.to; i++) { const r = S[i]; if (r) { done++; stars += r.s; } }
    const locked = ch.from > Progress.data.top;
    return `<div class="rec d-${ch.tone}"><b>${ch.no}장 · ${ch.name}</b><span>${locked ? '잠겨 있어요' : `<i>${done}/${total}</i> · ★ ${stars}`}</span></div>`;
  }).join('');
  renderSaveLines();
}

/* ---------------- rendering: chrome ---------------- */
function diffCards(container, current, onPick, disabled) {
  container.innerHTML = Object.values(DIFFS).map(d => `
    <button type="button" class="diff d-${d.key}" role="radio" aria-checked="${d.key === current}" data-diff="${d.key}" ${disabled ? 'disabled' : ''}>
      <span class="d-top"><b>${d.label}</b><span class="meter" aria-label="난이도 ${d.level}단계">${[1,2,3].map(l => svgUse('i-leaf', l <= d.level ? 'on' : '')).join('')}</span></span>
      <span class="d-name">${d.forest}</span>
      <span class="d-spec">${d.spec}</span>
      <span class="d-more">${d.more}</span>
    </button>`).join('');
  container.onclick = e => { const b = e.target.closest('.diff'); if (!b || b.disabled) return; onPick(b.dataset.diff); };
  container.onkeydown = e => {
    const keys = ['easy', 'normal', 'hard'], cur = keys.indexOf(container.querySelector('[aria-checked="true"]')?.dataset.diff);
    if (e.key === 'ArrowRight' || e.key === 'ArrowDown') { e.preventDefault(); onPick(keys[(cur + 1) % 3]); container.querySelector('[aria-checked="true"]')?.focus(); }
    if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') { e.preventDefault(); onPick(keys[(cur + 2) % 3]); container.querySelector('[aria-checked="true"]')?.focus(); }
  };
  container.querySelectorAll('.diff').forEach(b => { b.tabIndex = b.getAttribute('aria-checked') === 'true' ? 0 : -1; });
}
function renderRules(d) {
  const k = d.k, word = k === 1 ? '한 마리' : '두 마리';
  $('rules').innerHTML = `
    <span class="eyebrow">Detective’s guide</span>
    <h3>${d.label} · ${d.forest}의 규칙</h3>
    <ol>
      <li><div><b>색깔 구역마다 딱 ${word}</b><span>같은 색 구역에는 친구가 ${word}씩 숨어 있어요.</span></div></li>
      <li><div><b>가로 · 세로 줄마다 ${word}</b><span>${d.n}×${d.n} 보드라서 모두 ${d.n * k}마리를 찾아야 해요.</span></div></li>
      <li><div><b>서로 붙어 있지 않아요</b><span>대각선을 포함한 주변 8칸에는 다른 친구가 없어요.</span></div></li>
    </ol>
    <p class="foot">기회 ${d.hearts}번 · 힌트 ${d.hints}번${d.autoAllowed ? ' · 자동 × 표시 사용 가능' : ' · 자동 × 표시 없음'}. 모든 퍼즐은 추측 없이 논리만으로 풀려요.</p>`;
}
function renderHowto() {
  const fine = matchMedia('(hover: hover)').matches;
  const tapWord = fine ? '클릭' : '탭';
  const main = settings.mode === 'find'
    ? `<span><b>한 번 ${tapWord}</b>친구 찾기</span><span><b>드래그</b>연속 × 표시</span>`
    : `<span><b>한 번 ${tapWord}</b>× 표시</span><span><b>두 번 ${tapWord}</b>친구 찾기</span><span><b>드래그</b>연속 × 표시</span>`;
  $('howto').innerHTML = main + (fine ? `<span><b>키보드</b>방향키 이동 · Space × · Enter 찾기 · Z 되돌리기</span>` : '');
}
function renderPlayChrome() {
  const d = G ? G.d : DIFFS[Net.cfgCache?.diff || settings.diff];
  const pill = $('diffPill'); pill.className = `diff-pill d-${d.tone || d.key}`; pill.innerHTML = `${svgUse('i-leaf')}${d.stage ? `${d.n}×${d.n}` : d.label}`;
  pill.querySelector('svg').style.cssText = 'width:14px;height:14px';
  renderRules(d);
  renderHowto();
  const multi = !!Net.r;
  $('raceCard').hidden = !multi;
  $('recordCard').hidden = multi;
  $('giveupBtn').hidden = !multi;
  if (G) {
    $('puzzleNo').textContent = '#' + G.P.label;
    $('autoBtn').hidden = !G.d.autoAllowed;
    $('autoBtn').setAttribute('aria-pressed', String(!!G.auto));
  }
  if (!multi && G && G.P.stage) {
    const ch = d.chapter;
    $('phaseLabel').textContent = `${ch.no}장 · ${ch.name}`;
    $('playTitle').textContent = `스테이지 ${G.P.stage}`;
    $('boardLabel').textContent = `STAGE ${G.P.stage} / ${STAGE_COUNT}`;
    $('boardTitle').textContent = '나만의 탐정 노트';
    $('puzzleNo').textContent = `${Progress.cleared()} / ${STAGE_COUNT}`;
    $('lobby').hidden = true; $('gameArea').hidden = false;
    renderRecords();
  } else if (!multi) {
    $('phaseLabel').textContent = `혼자 하는 추리 · ${d.label}`;
    $('playTitle').textContent = `${d.forest} 탐험`;
    $('boardLabel').textContent = `SOLO · PUZZLE ${G ? G.P.label : ''}`;
    $('boardTitle').textContent = '나만의 탐정 노트';
    $('lobby').hidden = true; $('gameArea').hidden = false;
    renderRecords();
  }
}
function renderStatus(broke) {
  if (!G) return;
  const total = G.P.solution.length;
  $('foundText').textContent = `${G.found.size} / ${total}마리 발견`;
  $('foundBar').style.width = (G.found.size / total * 100) + '%';
  const hearts = $('hearts'), left = G.d.hearts - G.mistakes;
  hearts.innerHTML = Array.from({ length: G.d.hearts }, (_, j) => svgUse('i-heart', j < left ? '' : 'lost' + (broke && j === left ? ' breaking' : ''))).join('');
  hearts.setAttribute('aria-label', `남은 기회 ${left}번`);
  $('hintLeft').textContent = hintsLeft();
  const playing = canPlay();
  $('hintBtn').disabled = !playing || hintsLeft() <= 0;
  $('undoBtn').disabled = !playing;
  $('giveupBtn').disabled = !playing;
  $('autoBtn').disabled = !playing && G.status !== 'countdown';
  tickTimer();
}
function tickTimer() {
  if (!G) return;
  const pen = penaltyMs();
  $('timer').innerHTML = (G.startAt ? fmt(elapsed() + pen) : '00:00') + (pen ? `<small>힌트 +${pen / 1000}초</small>` : '');
}
setInterval(() => { if (G && G.status === 'playing') tickTimer(); }, 250);

function renderResult() {
  if (!G) return;
  if (G.multi) { renderMultiResult(); return; }
  if (G.P.stage) { renderStageResult(); return; }
  const box = $('result'), d = G.d, won = G.status === 'won';
  const stars = won ? (G.mistakes === 0 && G.hintsUsed === 0 ? 3 : G.mistakes + G.hintsUsed <= 2 ? 2 : 1) : 0;
  box.innerHTML = won ? `
    <svg class="trophy" aria-hidden="true"><use href="#i-trophy"/></svg>
    <h2>모든 친구를 찾았어요!</h2>
    <div class="stars" role="img" aria-label="별 ${stars}개">${[1,2,3].map(s => svgUse('i-star', s <= stars ? 'on' : '')).join('')}</div>
    <p class="r-sub">${d.forest} 퍼즐 ${G.P.label}을 ${fmt(elapsed())}만에 풀었어요.</p>
    <div class="r-stats"><span>기록 <b>${fmt(elapsed())}</b></span><span>실수 <b>${G.mistakes}</b></span><span>힌트 <b>${G.hintsUsed}</b></span></div>
    ${G.newBest ? '<span class="r-badge">새 최고 기록!</span>' : ''}` : `
    <svg class="trophy" aria-hidden="true"><use href="#i-sprout"/></svg>
    <h2>기회를 모두 썼어요</h2>
    <p class="r-sub">흐리게 보이는 칸이 친구들이 숨어 있던 곳이에요. 같은 퍼즐로 다시 도전해 볼까요?</p>
    <div class="r-stats"><span>찾은 친구 <b>${G.found.size}/${G.P.solution.length}</b></span><span>시간 <b>${fmt(elapsed())}</b></span></div>`;
  const acts = document.createElement('div'); acts.className = 'r-actions';
  if (!won) acts.append(button('같은 퍼즐 다시', 'btn btn-ghost', () => newGame(G.P.pid, { multi: false })));
  acts.append(button(`새 ${d.label} 퍼즐 ${svgUse('i-arrow')}`, 'btn btn-primary', () => newGame(pickPid(d.key), { multi: false })));
  acts.append(button('난이도 바꾸기', 'btn btn-ghost', () => goHome()));
  box.append(acts);
  box.hidden = false;
  setTimeout(() => box.scrollIntoView({ behavior: reduceMotion.matches ? 'auto' : 'smooth', block: 'nearest' }), 600);
}

function renderStageResult() {
  const box = $('result'), N = G.P.stage, ch = G.d.chapter, won = G.status === 'won', res = G.stageResult || {};
  const stats = `<div class="r-stats"><span>기록 <b>${fmt(elapsed())}</b></span><span>실수 <b>${G.mistakes}</b></span><span>힌트 <b>${G.hintsUsed}</b></span></div>`;
  if (won) {
    const badges = [];
    if (res.newBest) badges.push('<span class="hot">새 최고 기록!</span>');
    if (res.unlocked) badges.push('<span>다음 스테이지가 열렸어요</span>');
    if (res.first && N === ch.to && N < STAGE_COUNT) badges.push(`<span class="hot">${ch.no}장 ${ch.name} 완료! 다음은 ${chapterOf(N + 1).no}장 ${chapterOf(N + 1).name}</span>`);
    if (res.first && N === STAGE_COUNT) badges.push('<span class="hot">500개 스테이지를 모두 정복했어요!</span>');
    box.innerHTML = `
      <svg class="trophy" aria-hidden="true"><use href="#i-trophy"/></svg>
      <h2>스테이지 ${N} 클리어!</h2>
      <div class="stars" role="img" aria-label="별 ${G.stars}개">${[1,2,3].map(s => svgUse('i-star', s <= G.stars ? 'on' : '')).join('')}</div>
      <p class="r-sub">${ch.no}장 ${ch.name} · ${G.P.n}×${G.P.n} 보드를 ${fmt(elapsed())}만에 풀었어요.${G.stars < 3 ? ' 실수와 힌트 없이 풀면 별 3개예요.' : ''}</p>
      ${stats}<div class="stage-badges">${badges.join('')}</div>`;
  } else {
    box.innerHTML = `
      <svg class="trophy" aria-hidden="true"><use href="#i-sprout"/></svg>
      <h2>기회를 모두 썼어요</h2>
      <p class="r-sub">흐리게 보이는 칸이 친구들이 숨어 있던 곳이에요. 스테이지 ${N}에 다시 도전해 볼까요?</p>${stats}`;
  }
  const acts = document.createElement('div'); acts.className = 'r-actions';
  if (won && N < STAGE_COUNT) acts.append(button(`다음: 스테이지 ${N + 1} ${svgUse('i-arrow')}`, 'btn btn-primary', () => newGame('s' + (N + 1), { multi: false })));
  acts.append(button(won ? '다시 하기' : `다시 도전 ${svgUse('i-arrow')}`, won ? 'btn btn-ghost' : 'btn btn-primary', () => newGame('s' + N, { multi: false })));
  acts.append(button(`${svgUse('i-map')}스테이지 지도`, 'btn btn-ghost', () => showStages()));
  box.append(acts);
  const save = document.createElement('p'); save.className = 'save-line save-target'; save.style.justifyContent = 'center'; box.append(save);
  box.hidden = false;
  renderSaveLines();
  setTimeout(() => box.scrollIntoView({ behavior: reduceMotion.matches ? 'auto' : 'smooth', block: 'nearest' }), 600);
}

/* ---------------- stage progress (this device + account) ---------------- */
const Progress = {
  owner: 'guest', data: { stages: {}, top: 1 },
  key() { return 'progress:' + this.owner; },
  normalize(d) {
    const out = { stages: {}, top: 1 };
    if (d && typeof d === 'object') {
      const src = d.stages && typeof d.stages === 'object' ? d.stages : {};
      for (const k of Object.keys(src)) {
        const n = Number(k), v = src[k];
        if (!Number.isInteger(n) || n < 1 || n > STAGE_COUNT || !v || typeof v !== 'object') continue;
        out.stages[n] = { s: Math.max(1, Math.min(3, Math.floor(Number(v.s) || 1))), t: Math.max(0, Math.floor(Number(v.t) || 0)) };
      }
      out.top = Math.max(1, Math.min(STAGE_COUNT, Math.floor(Number(d.top) || 1)));
    }
    const maxDone = Object.keys(out.stages).reduce((m, k) => Math.max(m, Number(k)), 0);
    out.top = Math.min(STAGE_COUNT, Math.max(out.top, maxDone + 1));
    return out;
  },
  use(owner) { this.owner = owner; this.data = this.normalize(store.get(this.key(), null)); },
  saveLocal() { store.set(this.key(), this.data); },
  mergeIn(d) {
    const o = this.normalize(d);
    for (const k of Object.keys(o.stages)) {
      const cur = this.data.stages[k], v = o.stages[k];
      this.data.stages[k] = !cur ? v : { s: Math.max(cur.s, v.s), t: cur.t && v.t ? Math.min(cur.t, v.t) : (cur.t || v.t) };
    }
    this.data.top = Math.max(this.data.top, o.top);
    this.saveLocal();
  },
  record(N, stars, ms) {
    const cur = this.data.stages[N];
    const res = { first: !cur, newBest: !!cur && cur.t > 0 && ms < cur.t, unlocked: N >= this.data.top && N < STAGE_COUNT };
    this.data.stages[N] = { s: Math.max(stars, cur ? cur.s : 0), t: cur && cur.t ? Math.min(cur.t, ms) : ms };
    if (N >= this.data.top) this.data.top = Math.min(STAGE_COUNT, N + 1);
    this.saveLocal();
    Account.push();
    return res;
  },
  cleared() { return Object.keys(this.data.stages).length; },
  stars() { return Object.values(this.data.stages).reduce((s, v) => s + v.s, 0); },
  next() { for (let i = 1; i <= this.data.top; i++) if (!this.data.stages[i]) return i; return Math.min(STAGE_COUNT, this.data.top); },
};

/* ---------------- accounts (Firebase: ID + password, progress in Firestore) ---------------- */
function firebaseBackend(A, F, app, native) {
  // inside the app WebView, set persistence explicitly instead of getAuth()'s browser defaults
  const auth = native ? A.initializeAuth(app, { persistence: [A.indexedDBLocalPersistence, A.browserLocalPersistence] }) : A.getAuth(app), db = F.getFirestore(app);
  return {
    onUser: cb => A.onAuthStateChanged(auth, u => cb(u ? { uid: u.uid, email: u.email || '' } : null)),
    signUp: async (email, pw) => { const c = await A.createUserWithEmailAndPassword(auth, email, pw); return { uid: c.user.uid, email }; },
    signIn: async (email, pw) => { const c = await A.signInWithEmailAndPassword(auth, email, pw); return { uid: c.user.uid, email }; },
    signOut: () => A.signOut(auth),
    load: async uid => { const s = await F.getDoc(F.doc(db, 'players', uid)); return s.exists() ? s.data() : null; },
    save: (uid, data) => F.setDoc(F.doc(db, 'players', uid), Object.assign({}, data, { updatedAt: F.serverTimestamp() }), { merge: true }),
    deleteAccount: async (email, pw) => {
      const c = await A.signInWithEmailAndPassword(auth, email, pw);
      await F.deleteDoc(F.doc(db, 'players', c.user.uid));
      await A.deleteUser(c.user);
      return c.user.uid;
    },
  };
}
const Account = {
  status: 'off', backend: null, user: null, id: '', carry: null, saving: false, again: false, saveState: 'idle', seenUid: undefined,
  async init() {
    if (window.__fdMockBackend) this.backend = window.__fdMockBackend;
    else if (FIREBASE_CONFIG && !window.claude) {
      this.status = 'loading'; renderAccount();
      try {
        let app, A, F;
        if (window.ForestFirebase) ({ app, A, F } = window.ForestFirebase);
        else {
          const base = `https://www.gstatic.com/firebasejs/${FB_VER}/`;
          [app, A, F] = await Promise.all([import(base + 'firebase-app.js'), import(base + 'firebase-auth.js'), import(base + 'firebase-firestore-lite.js')]);
        }
        this.backend = firebaseBackend(A, F, app.initializeApp(FIREBASE_CONFIG), Native.is());
      } catch { this.status = 'error'; renderAccount(); return; }
    } else { this.status = 'off'; renderAccount(); return; }
    this.status = 'ready';
    this.backend.onUser(u => this.onUser(u));
    renderAccount();
  },
  domain() { return window.__fdMockBackend ? 'players.test' : FIREBASE_CONFIG.authDomain; },
  onUser(u) {
    // runs once per sign-in state (called after login/sign-up/logout and by Firebase's listener); repeat callers wait for the same load
    const uid = u ? u.uid : null;
    if (uid === this.seenUid) return this.pending;
    this.seenUid = uid;
    this.pending = this.applyUser(u);
    return this.pending;
  },
  async applyUser(u) {
    this.user = u; this.id = u ? String(u.email).split('@')[0] : '';
    this.saveState = u ? 'loading' : 'idle';
    renderAccount();
    if (u) {
      Progress.use(u.uid);
      try {
        const data = await this.backend.load(u.uid);
        if (data) { Progress.mergeIn(data); applyProfile(data); }
        if (this.carry) { Progress.mergeIn(this.carry); this.carry = null; }
        await this.push();
      } catch (e) { this.saveState = 'error'; toast(authError(e)); }
    } else {
      Progress.use('guest');
      this.saveState = 'idle';
    }
    renderAccount(); renderSoloPanel(); if (!$('stages').hidden) renderStageMap(); if (G && G.P.stage && !$('play').hidden) renderRecords();
  },
  async signUp(id, pw) {
    this.carry = Progress.owner === 'guest' ? JSON.parse(JSON.stringify(Progress.data)) : null;
    let u; try { u = await this.backend.signUp(`${id}@${this.domain()}`, pw); } catch (e) { this.carry = null; throw e; }
    await this.onUser(u);
  },
  async signIn(id, pw) { const u = await this.backend.signIn(`${id}@${this.domain()}`, pw); await this.onUser(u); },
  async signOut() { await this.backend.signOut(); await this.onUser(null); },
  async deleteAccount(pw) {
    const uid = await this.backend.deleteAccount(`${this.id}@${this.domain()}`, pw);
    try { localStorage.removeItem('fd2:progress:' + uid); } catch {}
    await this.onUser(null);
  },
  async push() {
    if (!this.user) return;
    if (this.saving) { this.again = true; return; }
    this.saving = true; this.saveState = 'saving'; renderSaveLines();
    try {
      await this.backend.save(this.user.uid, { id: this.id, name: settings.name, animal: settings.animal, stages: Progress.data.stages, top: Progress.data.top, stars: Progress.stars(), cleared: Progress.cleared() });
      this.saveState = 'saved';
    } catch { this.saveState = 'error'; }
    this.saving = false; renderSaveLines();
    if (this.again) { this.again = false; this.push(); }
  },
};
function authError(e) {
  const c = String((e && e.code) || '');
  if (/email-already-in-use/.test(c)) return '이미 사용 중인 아이디예요. 다른 아이디를 골라 주세요.';
  if (/invalid-credential|wrong-password|user-not-found|invalid-login-credentials|invalid-email/.test(c)) return '아이디 또는 비밀번호가 맞지 않아요.';
  if (/weak-password/.test(c)) return '비밀번호는 6자 이상이어야 해요.';
  if (/too-many-requests/.test(c)) return '시도가 너무 많았어요. 잠시 후 다시 해 주세요.';
  if (/network-request-failed|unavailable/.test(c)) return '인터넷 연결을 확인하고 다시 시도해 주세요.';
  if (/operation-not-allowed|configuration-not-found/.test(c)) return '로그인 기능이 아직 켜지지 않았어요. (Firebase에서 이메일/비밀번호 로그인을 사용 설정해 주세요)';
  if (/permission-denied/.test(c)) return '기록을 저장할 권한이 없어요. (Firestore 규칙을 확인해 주세요)';
  return '문제가 생겼어요. 잠시 후 다시 시도해 주세요.';
}
function applyProfile(d) {
  if (d.name && typeof d.name === 'string') { settings.name = d.name.slice(0, 12); store.set('name', settings.name); $('nameInput').value = settings.name; }
  if (ANIMALS.some(x => x.id === d.animal)) { settings.animal = d.animal; store.set('animal', settings.animal); $('animals').querySelectorAll('.animal-btn').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.animal === settings.animal))); }
}
function saveLineHTML() {
  if (Account.status === 'ready' && Account.user) {
    const st = Account.saveState === 'loading' ? '계정 기록을 불러오는 중…' : Account.saveState === 'saving' ? '저장하는 중…' : Account.saveState === 'error' ? '계정에 저장하지 못했어요. 인터넷이 연결되면 다음 기록 때 다시 저장해요.' : `<b>${esc(Account.id)}</b> 계정에 저장돼요. 다른 기기에서도 이어서 할 수 있어요.`;
    return `${svgUse('i-cloud')}<span>${st}</span>`;
  }
  if (Account.status === 'ready') return `${svgUse('i-device')}<span>지금은 이 기기에만 저장돼요. <button type="button" data-acct="in">로그인</button>하거나 <button type="button" data-acct="up">회원가입</button>하면 어디서나 이어서 할 수 있어요.</span>`;
  if (Account.status === 'loading') return `${svgUse('i-device')}<span>계정 기능을 불러오는 중…</span>`;
  return `${svgUse('i-device')}<span>기록은 이 기기에 저장돼요.</span>`;
}
function renderSaveLines() {
  const html = saveLineHTML();
  ['soloSave', 'playSave'].forEach(id => { const el = $(id); if (el) el.innerHTML = html; });
  document.querySelectorAll('.save-target').forEach(el => { el.innerHTML = html; });
}
function renderAccount() {
  const btn = $('acctBtn');
  btn.hidden = Account.status === 'off';
  if (Account.user) btn.innerHTML = `<svg class="av" aria-hidden="true"><use href="#a-${settings.animal}"/></svg><span class="lbl">${esc(Account.id)}</span>`;
  else btn.innerHTML = `<svg aria-hidden="true"><use href="#i-user"/></svg><span class="lbl">${Account.status === 'loading' ? '불러오는 중' : '로그인'}</span>`;
  btn.setAttribute('aria-label', Account.user ? `내 계정 ${Account.id}` : '로그인 또는 회원가입');
  renderSaveLines();
}
let acctMode = 'in';
function setAcctMode(m) {
  acctMode = m;
  $('acctTabIn').setAttribute('aria-selected', String(m === 'in'));
  $('acctTabUp').setAttribute('aria-selected', String(m === 'up'));
  $('acctPw2Wrap').hidden = m !== 'up';
  $('acctTitle').textContent = m === 'up' ? '회원가입' : '로그인';
  $('acctSubmitText').textContent = m === 'up' ? '가입하고 시작하기' : '로그인';
  $('acctPw').setAttribute('autocomplete', m === 'up' ? 'new-password' : 'current-password');
  $('acctFoot').textContent = m === 'up'
    ? '비밀번호는 되찾을 수 없으니 꼭 기억해 두세요. 지금 이 기기에서 깬 스테이지 기록은 새 계정으로 옮겨져요.'
    : '로그인하면 스테이지 기록이 계정에 저장돼서 다른 기기에서도 이어서 할 수 있어요.';
  $('acctErr').hidden = true;
}
function openAccount(mode) {
  if (Account.status !== 'ready') { toast(Account.status === 'loading' ? '계정 기능을 불러오는 중이에요. 잠시 후 다시 눌러 주세요.' : '지금은 로그인을 쓸 수 없어요. 인터넷 연결을 확인해 주세요.'); return; }
  const me = !!Account.user;
  $('acctGuest').hidden = me; $('acctMe').hidden = !me;
  if (me) {
    $('acctTitle').textContent = '내 계정';
    $('acctMeAv').innerHTML = `<use href="#a-${settings.animal}"/>`;
    $('acctMeName').textContent = settings.name || '이름 없는 탐정';
    $('acctMeId').textContent = `아이디 ${Account.id}`;
    $('acctMeSave').textContent = `스테이지 ${Progress.cleared()}개 클리어 · 별 ${Progress.stars()}개 · 기록이 계정에 저장돼요.`;
    $('delPw').value = ''; $('delErr').hidden = true; $('acctDel').open = false;
  } else { setAcctMode(mode || 'in'); $('acctPw').value = ''; $('acctPw2').value = ''; }
  try { $('acctDlg').showModal(); } catch { $('acctDlg').setAttribute('open', ''); }
  if (!me) setTimeout(() => $('acctId').focus(), 50);
}
async function deleteMyAccount() {
  const btn = $('delBtn'), err = msg => { $('delErr').textContent = msg; $('delErr').hidden = false; };
  $('delErr').hidden = true;
  if ($('delPw').value.length < 6) return err('계정을 지우려면 비밀번호를 다시 입력해 주세요.');
  if (!btn.dataset.armed) { btn.dataset.armed = '1'; btn.textContent = '한 번 더 누르면 영구 삭제돼요'; setTimeout(() => { delete btn.dataset.armed; btn.textContent = '계정 영구 삭제'; }, 4000); return; }
  delete btn.dataset.armed; btn.disabled = true; btn.textContent = '삭제하는 중…';
  const id = Account.id;
  try { await Account.deleteAccount($('delPw').value); $('acctDlg').close(); toast(`${id} 계정과 기록을 모두 지웠어요.`); }
  catch (ex) { err(authError(ex)); }
  finally { btn.disabled = false; btn.textContent = '계정 영구 삭제'; $('delPw').value = ''; }
}
async function submitAccount(e) {
  e.preventDefault();
  const id = $('acctId').value.trim().toLowerCase(), pw = $('acctPw').value, pw2 = $('acctPw2').value;
  const err = msg => { $('acctErr').textContent = msg; $('acctErr').hidden = false; };
  if (!/^[a-z0-9_]{4,16}$/.test(id)) return err('아이디는 영문 소문자, 숫자, 밑줄(_)로 4~16자여야 해요.');
  if (pw.length < 6) return err('비밀번호는 6자 이상이어야 해요.');
  if (acctMode === 'up' && pw !== pw2) return err('비밀번호 확인이 달라요. 같은 비밀번호를 두 번 입력해 주세요.');
  const btn = $('acctSubmit'), label = $('acctSubmitText').textContent;
  btn.disabled = true; $('acctSubmitText').textContent = '확인하는 중…'; $('acctErr').hidden = true;
  try {
    if (acctMode === 'up') await Account.signUp(id, pw); else await Account.signIn(id, pw);
    $('acctDlg').close();
    toast(acctMode === 'up' ? `${id} 계정을 만들었어요! 이제 기록이 계정에 저장돼요.` : `${id} 님, 다시 만나서 반가워요!`);
  } catch (ex) { err(authError(ex)); }
  finally { btn.disabled = false; $('acctSubmitText').textContent = label; }
}

/* ---------------- stage map ---------------- */
function showStages() {
  if (Net.r) return;
  clearTimeout(countdownTimer); G = null; FX.clear(); hideHintSafe();
  showScreen('stages');
  renderStageMap();
  requestAnimationFrame(() => { const cur = document.querySelector('.stg.cur'); if (cur) cur.scrollIntoView({ block: 'center', behavior: 'auto' }); });
}
function renderStageMap() {
  const S = Progress.data.stages, top = Progress.data.top, next = Progress.next();
  $('stagesSum').innerHTML = `<span>클리어 <b>${Progress.cleared()}</b> / ${STAGE_COUNT}</span><span>${svgUse('i-star')}<b>${Progress.stars()}</b> / ${STAGE_COUNT * 3}</span><span>다음 도전 <b>스테이지 ${next}</b></span>`;
  $('chapters').innerHTML = CHAPTERS.map(ch => {
    const total = ch.to - ch.from + 1, sz = stageSize(ch.from); let done = 0, stars = 0;
    const btns = [];
    for (let N = ch.from; N <= ch.to; N++) {
      const r = S[N], locked = N > top;
      if (r) { done++; stars += r.s; }
      const cls = ['stg']; if (r) cls.push('done'); if (N === next && !r) cls.push('cur');
      btns.push(`<button type="button" class="${cls.join(' ')}" data-stage="${N}"${locked ? ' disabled' : ''} aria-label="스테이지 ${N}${r ? `, 별 ${r.s}개` : locked ? ', 잠김' : ''}">${N}${locked ? svgUse('i-lock', 'lock') : `<span class="st3">${[1,2,3].map(s => svgUse('i-star', r && s <= r.s ? 'on' : '')).join('')}</span>`}</button>`);
    }
    return `<section class="card chapter d-${ch.tone}"><div class="ch-head"><h2>${ch.no}장 · ${ch.name}<small>${sz}×${sz} · 스테이지 ${ch.from}–${ch.to}</small></h2><div class="ch-meta"><span>${done}/${total} · ★ ${stars}</span><div class="bar" aria-hidden="true"><i style="width:${done / total * 100}%"></i></div></div></div><div class="stage-grid">${btns.join('')}</div></section>`;
  }).join('');
}
function renderSoloPanel() {
  const next = Progress.next(), ch = chapterOf(next), n = stageSize(next), cleared = Progress.cleared(), all = cleared >= STAGE_COUNT;
  $('soloChapter').textContent = `${ch.no}장 · ${ch.name}`;
  $('soloStars').textContent = `${Progress.stars()} / ${STAGE_COUNT * 3}`;
  $('soloStage').textContent = all ? '모든 스테이지 클리어!' : `스테이지 ${next}`;
  $('soloSpec').textContent = `${n}×${n} · 기회 ${ch.hearts} · 힌트 ${ch.hints}`;
  $('soloBar').style.width = (cleared / STAGE_COUNT * 100) + '%';
  $('soloCleared').textContent = `${STAGE_COUNT}개 스테이지 중 ${cleared}개 클리어`;
  $('soloBtnText').textContent = all ? `스테이지 ${next} 다시 하기` : cleared ? `스테이지 ${next} 이어서 도전` : '스테이지 1부터 시작';
  renderSaveLines();
}

/* ---------------- multiplayer (live room) ---------------- */
function sanitize(p) {
  const s = p.presence || {};
  if (s.app !== 'fd2') return null;
  const num = (v, max) => Math.max(0, Math.min(max, Math.floor(Number(v) || 0)));
  let cfg = null;
  if (s.cfg && typeof s.cfg === 'object' && DIFFS[s.cfg.diff]) {
    const pid = parsePid(s.cfg.pid) && LETTER[String(s.cfg.pid)[0]] === s.cfg.diff ? String(s.cfg.pid) : '';
    cfg = { diff: s.cfg.diff, pid, round: num(s.cfg.round, 1e6), phase: s.cfg.phase === 'playing' && pid ? 'playing' : 'lobby' };
  }
  return { peer: p.peer, mine: !!(p.isMe && p.sameTab), name: String(s.name || '탐정').slice(0, 12) || '탐정', animal: ANIMALS.some(a => a.id === s.animal) ? s.animal : 'fox',
    joinedAt: Number(s.joinedAt) || 0, ready: !!s.ready, host: !!s.host, hostSince: Number(s.hostSince) || 0, cfg,
    round: num(s.round, 1e6), spec: !!s.spec, found: num(s.found, 100), total: num(s.total, 100), mistakes: num(s.mistakes, 10), hearts: num(s.hearts, 10),
    out: !!s.out, done: num(s.done, 864e5), pen: num(s.pen, 36e5) };
}
function makeP2PRoomApi() {
  const T = window.ForestTrystero;
  return {
    async join(name) {
      const listeners = new Set(), others = new Map();
      let mine = {}, scheduled = false;
      const relays = ['nos.lol', 'relay.primal.net', 'offchain.pub', 'relay.snort.social', 'nostr.mom', 'relay.nostr.net', 'relay.nostr.wirednet.jp'].map(h => 'wss://' + h);
      const room = T.joinRoom({ appId: 'forest-detectives-kr-2026', password: 'fd2:' + name, relayConfig: { urls: relays, redundancy: relays.length } }, name, { onJoinError: () => {} });
      const snapshot = () => [
        { peer: T.selfId, by: null, isMe: true, sameTab: true, kind: 'viewer', guest: false, presence: Object.assign({}, mine), updatedAt: Date.now() },
        ...[...others.entries()].map(([peer, presence]) => ({ peer, by: null, isMe: false, sameTab: false, kind: 'viewer', guest: false, presence, updatedAt: Date.now() })),
      ];
      const notify = () => {
        if (scheduled) return; scheduled = true;
        setTimeout(() => { scheduled = false; const s = snapshot(); listeners.forEach(fn => { try { fn({ peers: s, joined: [], left: [], updated: [] }); } catch {} }); }, 0);
      };
      const pres = room.makeAction('pres', {
        onMessage: (data, ctx) => { if (data && typeof data === 'object' && !Array.isArray(data) && JSON.stringify(data).length < 4096) { others.set(ctx.peerId, data); notify(); } },
      });
      const send = target => pres.send(mine, target ? { target } : undefined).catch(() => {});
      room.onPeerJoin = peer => { if (!others.has(peer)) others.set(peer, {}); send(peer); notify(); };
      room.onPeerLeave = peer => { others.delete(peer); notify(); };
      const beat = setInterval(() => { if (others.size) send(); }, 4000);
      return {
        name,
        async presence(patch) { for (const k in patch) { if (patch[k] === null) delete mine[k]; else mine[k] = patch[k]; } notify(); send(); },
        peers: snapshot,
        onPeers(fn) { listeners.add(fn); notify(); return () => listeners.delete(fn); },
        onConnection(fn) { setTimeout(() => fn(true), 0); return () => {}; },
        connected: () => true,
        async leave() { clearInterval(beat); listeners.clear(); try { await room.leave(); } catch {} },
      };
    },
  };
}
const Net = {
  kind: 'none',
  api: null, checked: false, r: null, code: null, me: {}, cfgCache: null, firstCfg: true, myRound: 0, spec: false,
  seenHost: false, hostless: 0, waitTimer: 0, unsubs: [], connected: false, prevDone: new Map(),
  async init() {
    let api = null, kind = 'none';
    if (window.claude && typeof window.claude.use === 'function') {
      try { api = await window.claude.use('room'); } catch { api = null; }
      if (api) kind = 'claude';
    }
    if (!api && window.ForestTrystero && typeof RTCPeerConnection === 'function') { api = makeP2PRoomApi(); kind = 'p2p'; }
    this.api = api; this.kind = kind; this.checked = true; renderOnlineAvailability(); renderInviteCopy();
  },
  newCode() { const A = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789', v = new Uint32Array(6); crypto.getRandomValues(v); return Array.from(v, x => A[x % A.length]).join(''); },
  async enter(code, asHost) {
    if (!this.api) { toast('이 화면에서는 온라인 방을 열 수 없어요. 혼자 하기로 즐겨 주세요.'); return false; }
    let r;
    try { r = await this.api.join('fd-' + code.toLowerCase()); }
    catch (e) { toast(e && e.code === 'limit_reached' ? '지금은 방이 너무 많아요. 잠시 후 다시 시도해 주세요.' : '방에 들어가지 못했어요. 잠시 후 다시 시도해 주세요.'); return false; }
    Object.assign(this, { r, code, firstCfg: true, myRound: 0, spec: false, seenHost: asHost, cfgCache: null, prevDone: new Map() });
    const base = { app: 'fd2', name: settings.name, animal: settings.animal, joinedAt: Date.now(), ready: false, host: false, hostSince: 0, cfg: null, round: 0, spec: false, found: 0, total: 0, mistakes: 0, hearts: 0, out: false, done: 0, pen: 0 };
    if (asHost) { base.host = true; base.hostSince = Date.now(); base.cfg = { diff: settings.diff, pid: '', round: 0, phase: 'lobby' }; this.cfgCache = base.cfg; }
    this.me = base;
    try { await r.presence(base); }
    catch { toast('방에 들어가지 못했어요. 잠시 후 다시 시도해 주세요.'); try { await r.leave(); } catch {} this.r = null; return false; }
    G = null;
    this.unsubs.push(r.onPeers(() => this.onPeers(), e => this.onErr(e)));
    this.unsubs.push(r.onConnection(ok => { this.connected = ok; renderConn(); }, () => {}));
    const p2p = this.kind === 'p2p';
    if (!asHost) this.waitTimer = setTimeout(() => { if (this.r && !this.seenHost) { toast(p2p ? '방을 찾지 못했어요. 코드가 맞는지, 방장이 게임 화면을 열어 두었는지 확인해 주세요.' : '방을 찾지 못했어요. 코드를 다시 확인해 주세요.'); leaveRoom(); } }, p2p ? 20000 : 8000);
    setTimeout(() => this.checkFull(), p2p ? 8000 : 3000);
    try { history.replaceState(null, '', '#room-' + code.toLowerCase()); } catch {}
    showScreen('play'); renderPlayChrome(); renderRoom();
    return true;
  },
  set(patch) { Object.assign(this.me, patch); if (this.r) this.r.presence(patch).catch(() => {}); },
  players() {
    if (!this.r) return [];
    const out = []; for (const p of this.r.peers()) { const s = sanitize(p); if (s) out.push(s); }
    return out.sort((a, b) => a.joinedAt - b.joinedAt || (a.peer < b.peer ? -1 : 1));
  },
  host(players) {
    const hs = (players || this.players()).filter(p => p.host && p.cfg);
    hs.sort((a, b) => a.hostSince - b.hostSince || (a.peer < b.peer ? -1 : 1));
    return hs[0] || null;
  },
  amHost(players) { const h = this.host(players); return !!h && h.mine; },
  onPeers() {
    if (!this.r) return;
    const players = this.players(), h = this.host(players);
    if (h) {
      this.seenHost = true; clearTimeout(this.waitTimer); clearTimeout(this.hostless); this.hostless = 0;
      if (this.me.host && !h.mine) this.set({ host: false, cfg: null });
      this.cfgCache = h.cfg;
      this.handleCfg(h.cfg, h.mine);
    } else if (this.seenHost && !this.hostless) {
      this.hostless = setTimeout(() => this.claimHost(), 2500);
    }
    for (const p of players) {
      const was = this.prevDone.get(p.peer) || 0;
      if (p.done && !was && !p.mine && this.cfgCache && p.round === this.cfgCache.round) { toast(`${p.name} 탐정이 모든 친구를 찾았어요!`); Sfx.play('other'); }
      this.prevDone.set(p.peer, p.done);
    }
    renderRoom();
  },
  claimHost() {
    this.hostless = 0;
    const players = this.players(); if (!this.r || this.host(players)) return;
    const cand = players[0];
    if (cand && cand.mine && this.cfgCache) { this.set({ host: true, hostSince: Date.now(), cfg: this.cfgCache }); toast('방장이 나가서 내가 새 방장이 됐어요.'); }
  },
  handleCfg(cfg, mine) {
    const first = this.firstCfg; this.firstCfg = false;
    if (cfg.phase === 'playing' && cfg.pid && cfg.round > this.myRound) {
      this.myRound = cfg.round;
      const d = DIFFS[cfg.diff];
      if (first && !mine) { this.spec = true; this.set({ round: cfg.round, spec: true, ready: false }); newGame(cfg.pid, { multi: true, spectate: true }); }
      else { this.spec = false; this.set({ round: cfg.round, spec: false, ready: false, found: 0, total: d.n * d.k, mistakes: 0, hearts: d.hearts, out: false, done: 0, pen: 0 }); newGame(cfg.pid, { multi: true }); }
    }
  },
  hostStart() {
    const players = this.players(); if (!this.amHost(players)) return;
    const diff = (this.cfgCache && this.cfgCache.diff) || settings.diff;
    const cfg = { diff, pid: pickPid(diff), round: Math.max((this.cfgCache && this.cfgCache.round) || 0, this.myRound) + 1, phase: 'playing' };
    this.cfgCache = cfg; this.set({ cfg });
    this.onPeers();
  },
  hostSetDiff(diff) {
    if (!this.amHost() || !DIFFS[diff]) return;
    const cfg = Object.assign({}, this.cfgCache, { diff });
    this.cfgCache = cfg; this.set({ cfg }); settings.diff = diff; store.set('diff', diff);
    renderRoom();
  },
  report() {
    if (!this.r || !G || !G.multi || G.spectate) return;
    this.set({ found: G.found.size, mistakes: G.mistakes, hearts: G.d.hearts - G.mistakes, out: G.status === 'lost' || G.status === 'gaveup', done: G.status === 'won' ? Math.max(1, Math.round(G.endAt - G.startAt)) : 0, pen: penaltyMs() });
  },
  async leave() {
    this.unsubs.forEach(u => { try { u(); } catch {} }); this.unsubs = [];
    clearTimeout(this.waitTimer); clearTimeout(this.hostless); this.hostless = 0;
    const r = this.r; this.r = null; this.code = null; this.cfgCache = null;
    if (r) { try { await r.leave(); } catch {} }
    try { history.replaceState(null, '', location.pathname + location.search); } catch {}
  },
  onErr(e) { if (e && ['revoked', 'not_granted', 'capability_disabled', 'capability_removed', 'transform_error'].includes(e.code)) { toast('온라인 방 연결이 끊겼어요.'); leaveRoom(); } },
  checkFull() {
    if (!this.r) return;
    const idx = this.players().findIndex(p => p.mine);
    if (idx >= 4) { toast('방이 가득 찼어요. 최대 4명까지 함께할 수 있어요.'); leaveRoom(); }
  },
};
function roundInfo() {
  const players = Net.players(), cfg = Net.cfgCache;
  if (!cfg || cfg.phase !== 'playing') return { players, cfg, parts: [], finished: [], over: false };
  const parts = players.filter(p => p.round === cfg.round && !p.spec);
  const finished = parts.filter(p => p.done > 0).sort((a, b) => (a.done + a.pen) - (b.done + b.pen));
  const over = parts.length > 0 && parts.every(p => p.done > 0 || p.out);
  return { players, cfg, parts, finished, over };
}
function renderConn() {
  const el = $('conn');
  let ok = Net.connected, text = ok ? '실시간으로 연결됨' : '연결 재시도 중 · 잠시 기다려 주세요';
  if (Net.kind === 'p2p' && Net.r) {
    const others = Net.players().filter(p => !p.mine).length;
    ok = Net.seenHost;
    text = !Net.seenHost ? '방장과 연결하는 중… 최대 20초 걸려요' : others ? `친구 ${others}명과 직접 연결됨` : '친구가 들어오기를 기다리는 중';
  }
  el.classList.toggle('off', !ok); el.querySelector('span').textContent = text;
}
function renderInviteCopy() {
  if (Net.kind !== 'p2p') return;
  $('copyInvite').lastChild.textContent = Native.plugin('Share') ? '친구 초대하기' : '초대 링크 복사';
  $('lobbyText').textContent = '초대 링크를 친구에게 보내 주세요. 링크를 열고 이름만 적으면 바로 이 방으로 들어와요. 각자 다른 곳에서도 같은 퍼즐로 대결할 수 있어요.';
}
function inviteLink() { return (Native.is() ? SITE_URL : location.origin + location.pathname) + '#room-' + String(Net.code || '').toLowerCase(); }
function renderRoom() {
  if (!Net.r) return;
  const ri = roundInfo(), { players, cfg } = ri;
  const host = Net.host(players), iAmHost = !!host && host.mine;
  const inLobby = !cfg || cfg.phase === 'lobby' || !G;
  const d = DIFFS[(G && !inLobby ? G.P.diff : cfg && cfg.diff) || settings.diff];
  $('phaseLabel').textContent = inLobby ? '탐정들이 모이는 중' : ri.over ? '오늘의 추리 결과' : '같은 퍼즐, 각자의 추리';
  $('playTitle').textContent = inLobby ? '친구를 초대해 주세요' : `숲속 레이스 · ${cfg.round}번째 판`;
  $('boardLabel').textContent = (inLobby ? 'ROOM ' : 'PRIVATE BOARD · ') + Net.code;
  $('boardTitle').textContent = inLobby ? `${d.forest}에서 만나요` : '나만의 탐정 노트';
  const pill = $('diffPill'); pill.className = `diff-pill d-${d.key}`; pill.innerHTML = `${svgUse('i-leaf')}${d.label}`; pill.querySelector('svg').style.cssText = 'width:14px;height:14px';
  renderRules(d);
  $('lobby').hidden = !inLobby; $('gameArea').hidden = inLobby;
  if (inLobby) {
    $('timer').textContent = '00:00';
    $('bigCode').innerHTML = Net.code.split('').map(ch => `<span>${esc(ch)}</span>`).join('');
    const arts = players.slice(0, 3).map(p => p.animal); const fill = ['fox', 'rabbit', 'bear'];
    while (arts.length < 3) arts.push(fill.find(a => !arts.includes(a)) || 'owl');
    $('inviteArt').innerHTML = [arts[1], arts[0], arts[2]].map(a => svgUse('a-' + a)).join('');
    diffCards($('lobbyDiffs'), cfg ? cfg.diff : settings.diff, k => Net.hostSetDiff(k), !iAmHost);
    $('lobbyDiffNote').textContent = iAmHost ? '내가 방장이라 바꿀 수 있어요' : '방장이 정해요';
  }
  // racers
  $('playerCount').textContent = `${Math.min(players.length, 4)} / 4`;
  const box = $('racers');
  box.innerHTML = players.slice(0, 4).map(p => {
    const role = (host && p.peer === host.peer ? '방장' : '탐정') + (p.guest ? ' · 손님' : '') + (p.mine ? ' · 나' : '');
    let st = '', cls = '', pct = 0;
    const inRound = !inLobby && p.round === cfg.round && !p.spec;
    if (inLobby) { st = p.host || p.ready ? '준비 완료' : '대기 중'; cls = p.ready || p.host ? 'ok' : ''; }
    else if (!inRound) st = '관전 중';
    else if (p.done) { const rank = ri.finished.findIndex(f => f.peer === p.peer) + 1; st = `${rank}등 · ${fmt(p.done + p.pen)}`; cls = 'ok'; pct = 100; }
    else if (p.out) { st = '탈락'; cls = 'out'; pct = p.total ? p.found / p.total * 100 : 0; }
    else { pct = p.total ? p.found / p.total * 100 : 0; st = `${p.found}/${p.total} · ${'♥'.repeat(Math.min(p.hearts, 5))}`; }
    const trail = inLobby || !inRound ? '' : `<div class="trail"><i class="done-line" style="width:calc((100% - 30px) * ${pct / 100})"></i>${svgUse('i-flag', 'goal')}<svg class="runner" style="left:calc(13px + (100% - 40px) * ${pct / 100})" aria-hidden="true"><use href="#a-${p.animal}"/></svg></div>`;
    return `<div class="racer${p.mine ? ' me' : ''}${p.out && inRound ? ' out' : ''}"><div class="racer-line"><svg class="av" aria-hidden="true"><use href="#a-${p.animal}"/></svg><div class="nm">${esc(p.name)}<small>${role}</small></div><div class="st ${cls}">${st}</div></div>${trail}</div>`;
  }).join('') + (inLobby ? Array.from({ length: Math.max(0, 4 - players.length) }, () => '<div class="empty-seat">+ 친구를 기다리고 있어요</div>').join('') : '');
  // room actions
  const acts = $('roomActions'); acts.innerHTML = '';
  const me = players.find(p => p.mine);
  if (inLobby) {
    if (iAmHost) {
      const others = players.filter(p => !p.mine).slice(0, 3), allReady = others.length >= 1 && others.every(p => p.ready);
      const b = button(`3초 후 함께 시작 ${svgUse('i-arrow')}`, 'btn btn-primary', () => Net.hostStart());
      b.disabled = !allReady; acts.append(b);
      const tip = document.createElement('p'); tip.className = 'muted small'; tip.style.textAlign = 'center';
      tip.textContent = others.length < 1 ? '친구가 1명 이상 들어와야 시작할 수 있어요.' : allReady ? '모두 준비됐어요!' : '모든 친구가 준비를 마치면 시작할 수 있어요.';
      acts.append(tip);
    } else if (me) {
      acts.append(button(me.ready ? `${svgUse('i-check')} 준비 완료 · 취소하기` : '준비 완료', me.ready ? 'btn btn-ghost' : 'btn btn-primary', () => { Net.set({ ready: !Net.me.ready }); renderRoom(); }));
    }
  } else if (ri.over && iAmHost) {
    acts.append(button(`새 퍼즐로 한 판 더 ${svgUse('i-arrow')}`, 'btn btn-primary', () => Net.hostStart()));
  }
  renderConn();
  if (!inLobby && G && G.multi) renderMultiResult(ri);
}
function renderMultiResult(ri) {
  ri = ri || roundInfo();
  const box = $('result');
  const mineDone = G && (G.status === 'won' || G.status === 'lost' || G.status === 'gaveup');
  if (!G || (!mineDone && !ri.over && !G.spectate)) { box.hidden = true; return; }
  if (G.spectate && !ri.over) { box.hidden = true; return; }
  if (ri.over && !G.reveal && !G.spectate) { G.reveal = true; renderBoardState(); }
  const host = Net.host(ri.players), iAmHost = !!host && host.mine;
  const winner = ri.finished[0];
  let title, sub, icon = 'i-trophy';
  if (ri.over) { title = winner ? `${winner.name} 탐정의 승리!` : '이번 숲은 조금 어려웠네요'; sub = winner ? '모든 친구를 가장 먼저 찾았어요. 다음 숲에서도 도전해 보세요!' : '모두 찾은 탐정 없이 끝났어요. 새 퍼즐로 다시 도전해요.'; if (!winner) icon = 'i-sprout'; }
  else if (G.status === 'won') { const rank = ri.finished.findIndex(f => f.mine) + 1; title = rank === 1 ? '1등으로 완주했어요!' : `${rank || ''}등으로 완주했어요!`; sub = '다른 탐정들이 끝날 때까지 기다리는 중이에요.'; }
  else { title = G.status === 'gaveup' ? '이번 판을 포기했어요' : '기회를 모두 썼어요'; sub = '다른 탐정들이 끝나면 숨어 있던 친구들을 보여 드릴게요.'; icon = 'i-sprout'; }
  const rows = [...ri.finished, ...ri.parts.filter(p => !p.done && !p.out), ...ri.parts.filter(p => !p.done && p.out)];
  box.innerHTML = `
    <svg class="trophy" aria-hidden="true"><use href="#${icon}"/></svg>
    <h2>${esc(title)}</h2><p class="r-sub">${sub}</p>
    <ol class="ranking">${rows.map((p, j) => `<li><span class="rk">${p.done ? j + 1 : '·'}</span><svg class="rv" aria-hidden="true"><use href="#a-${p.animal}"/></svg><span class="rn">${esc(p.name)}${p.mine ? ' (나)' : ''}</span><span class="rt">${p.done ? `<i>${fmt(p.done + p.pen)}</i>` + (p.pen ? `<br><small>힌트 +${p.pen / 1000}초</small>` : '') : p.out ? '탈락' : `진행 중 ${p.found}/${p.total}`}</span></li>`).join('')}</ol>`;
  if (ri.over) {
    if (iAmHost) {
      const wrap = document.createElement('div'); wrap.className = 'lobby-diff';
      wrap.innerHTML = '<div class="field-label">다음 판 난이도</div><div class="diffs"></div>';
      box.append(wrap);
      diffCards(wrap.querySelector('.diffs'), (Net.cfgCache && Net.cfgCache.diff) || settings.diff, k => Net.hostSetDiff(k), false);
      const acts = document.createElement('div'); acts.className = 'r-actions';
      acts.append(button(`새 퍼즐로 한 판 더 ${svgUse('i-arrow')}`, 'btn btn-primary', () => Net.hostStart()));
      box.append(acts);
    } else {
      const p = document.createElement('p'); p.className = 'r-sub'; p.style.marginTop = '14px'; p.textContent = '방장이 다음 판을 시작하면 바로 함께 출발해요.'; box.append(p);
    }
  }
  box.hidden = false;
}
async function leaveRoom() { await Net.leave(); G = null; goHome(); }
function renderOnlineAvailability() {
  const ok = !!Net.api, note = $('onlineNote');
  $('createBtn').disabled = !ok; $('joinBtn').disabled = !ok;
  const onlineTab = $('tabCreate').getAttribute('aria-selected') === 'true' || $('tabJoin').getAttribute('aria-selected') === 'true';
  if (!Net.checked) { note.hidden = !onlineTab; note.textContent = '온라인 연결을 확인하고 있어요…'; return; }
  note.hidden = ok || !onlineTab;
  note.textContent = window.claude
    ? '이 claude.ai 페이지의 온라인 대결은 claude.ai에 로그인하고 이 페이지를 공유받은 친구끼리만 할 수 있어요. 지금 화면에서는 혼자 하기만 가능해요.'
    : '이 브라우저에서는 온라인 대결을 쓸 수 없어요. 최신 크롬·사파리·엣지에서 열어 주세요.';
}

/* ---------------- screens ---------------- */
function showScreen(name) {
  $('home').hidden = name !== 'home';
  $('play').hidden = name !== 'play';
  $('stages').hidden = name !== 'stages';
  if (name === 'play') requestAnimationFrame(() => FX.resize());
  window.scrollTo({ top: 0, behavior: 'auto' });
}
function goHome() {
  clearTimeout(countdownTimer);
  G = null; FX.clear(); hideHintSafe();
  showScreen('home');
  renderHome();
}
function hideHintSafe() { $('hintBox').hidden = true; }
function renderHome() { renderHomeStable(); }
function pickDiff(k) { settings.diff = k; store.set('diff', k); diffCards($('diffs'), k, pickDiff, false); }
function selectTab(which) {
  ['Solo', 'Create', 'Join'].forEach(w => { $('tab' + w).setAttribute('aria-selected', String(w === which)); $('panel' + w).hidden = w !== which; });
  renderOnlineAvailability();
}
function needName() {
  const v = $('nameInput').value.trim().slice(0, 12);
  settings.name = v; store.set('name', v);
  return v;
}

/* ---------------- hero mini board ---------------- */
function buildHero() {
  const P = { n: 5, regions: [0,0,1,1,1, 0,2,2,1,1, 3,3,2,2,1, 3,4,4,2,2, 3,4,4,2,2], palette: [0, 2, 3, 1, 6] };
  const grid = $('heroGrid'); grid.style.setProperty('--n', 5);
  const animals = { 1: 'fox', 8: 'rabbit', 10: 'bear', 17: 'panda', 24: 'owl' };
  const xs = [0, 2, 5, 6, 7, 11, 13, 15, 20, 21];
  grid.innerHTML = P.regions.map((_, i) => cellMarkup(P, i, { static: true, animal: animals[i] })).join('');
  const els = Array.from(grid.children);
  xs.forEach(i => els[i].classList.add('marked'));
  const order = [10, 1, 17, 8, 24];
  if (reduceMotion.matches) { order.forEach(i => els[i].classList.add('found')); return; }
  let k = 0;
  const step = () => {
    if (k < order.length) { els[order[k]].classList.add('found'); k++; }
    else { order.forEach(i => els[i].classList.remove('found')); k = 0; }
    setTimeout(step, k === 0 ? 900 : 1300);
  };
  setTimeout(step, 600);
}

/* ---------------- wiring ---------------- */
function wire() {
  $('brand').onclick = () => { if (Net.r) { $('leaveBtn').click(); return; } goHome(); };
  const syncToggle = () => {
    $('sfxBtn').setAttribute('aria-pressed', String(settings.sfx)); $('sfxBtn').setAttribute('aria-label', `효과음 ${settings.sfx ? '켜짐' : '꺼짐'}`);
    $('voiceBtn').setAttribute('aria-pressed', String(settings.voice)); $('voiceBtn').setAttribute('aria-label', `칭찬 음성 ${settings.voice ? '켜짐' : '꺼짐'}`);
  };
  syncToggle();
  $('sfxBtn').onclick = () => { settings.sfx = !settings.sfx; store.set('sfx', settings.sfx); syncToggle(); if (settings.sfx) Sfx.play('found'); };
  $('voiceBtn').onclick = () => { settings.voice = !settings.voice; store.set('voice', settings.voice); syncToggle(); if (settings.voice) speak('칭찬 음성을 켰어요. 멋진 추리를 기대할게요!'); else { try { speechSynthesis.cancel(); } catch {} const t = Native.plugin('TextToSpeech'); if (t) t.stop().catch(() => {}); } };
  $('helpBtn').onclick = () => { try { $('helpDlg').showModal(); } catch { $('helpDlg').setAttribute('open', ''); } };
  $('helpClose').onclick = $('helpOk').onclick = () => $('helpDlg').close();
  $('animals').onclick = e => { const b = e.target.closest('.animal-btn'); if (!b) return; settings.animal = b.dataset.animal; store.set('animal', settings.animal); $('animals').querySelectorAll('.animal-btn').forEach(x => x.setAttribute('aria-pressed', String(x === b))); if (Net.r) Net.set({ animal: settings.animal }); renderAccount(); Account.push(); };
  $('tabSolo').onclick = () => selectTab('Solo'); $('tabCreate').onclick = () => selectTab('Create'); $('tabJoin').onclick = () => selectTab('Join');
  $('nameInput').addEventListener('change', () => { needName(); Account.push(); });
  $('joinCode').addEventListener('input', () => { const el = $('joinCode'); el.value = el.value.toUpperCase().replace(/[^A-Z2-9]/g, '').slice(0, 6); });
  $('soloBtn').onclick = () => { needName(); newGame('s' + Progress.next(), { multi: false }); };
  $('mapBtn').onclick = () => { needName(); showStages(); };
  $('stagesBack').onclick = () => goHome();
  $('chapters').onclick = e => { const b = e.target.closest('.stg'); if (!b || b.disabled) return; newGame('s' + b.dataset.stage, { multi: false }); };
  $('acctBtn').onclick = () => openAccount('in');
  $('acctClose').onclick = () => $('acctDlg').close();
  $('acctTabIn').onclick = () => setAcctMode('in');
  $('acctTabUp').onclick = () => setAcctMode('up');
  $('acctForm').addEventListener('submit', submitAccount);
  $('acctId').addEventListener('input', () => { const el = $('acctId'); const v = el.value.toLowerCase().replace(/[^a-z0-9_]/g, ''); if (v !== el.value) el.value = v; });
  $('delBtn').onclick = deleteMyAccount;
  $('acctLogout').onclick = async () => { try { await Account.signOut(); $('acctDlg').close(); toast('로그아웃했어요. 이 기기의 게스트 기록으로 돌아왔어요.'); } catch (e) { toast(authError(e)); } };
  document.addEventListener('click', e => { const b = e.target.closest('[data-acct]'); if (b) openAccount(b.dataset.acct); });
  const online = async (asHost) => {
    if (!needName()) { toast('온라인 대결에서는 탐정 이름이 필요해요.'); $('nameInput').focus(); return; }
    let code;
    if (asHost) code = Net.newCode();
    else { code = $('joinCode').value.trim().toUpperCase(); if (!/^[A-Z2-9]{6}$/.test(code)) { toast('6자리 게임 코드를 확인해 주세요.'); $('joinCode').focus(); return; } }
    const btn = asHost ? $('createBtn') : $('joinBtn'); btn.disabled = true;
    try { await Net.enter(code, asHost); } finally { btn.disabled = !Net.api; }
  };
  $('createBtn').onclick = () => online(true);
  $('joinBtn').onclick = () => online(false);
  $('joinCode').addEventListener('keydown', e => { if (e.key === 'Enter') online(false); });
  $('leaveBtn').onclick = () => {
    const btn = $('leaveBtn');
    const risky = G && (G.status === 'playing' || G.status === 'countdown');
    if (risky && !btn.dataset.armed) { btn.dataset.armed = '1'; btn.querySelector('span').textContent = '한 번 더 누르면 나가요'; setTimeout(() => { delete btn.dataset.armed; btn.querySelector('span').textContent = '나가기'; }, 2600); return; }
    delete btn.dataset.armed; btn.querySelector('span').textContent = '나가기';
    if (Net.r) leaveRoom(); else goHome();
  };
  $('modeMark').onclick = () => setMode('mark');
  $('modeFind').onclick = () => setMode('find');
  $('undoBtn').onclick = undo;
  $('hintBtn').onclick = requestHint;
  $('autoBtn').onclick = () => {
    if (!G || !G.d.autoAllowed) return;
    G.auto = !G.auto; settings.auto[G.autoKey] = G.auto; store.set('auto', settings.auto);
    $('autoBtn').setAttribute('aria-pressed', String(G.auto));
    if (G.auto) { G.found.forEach(c => autoMarkAround(c)); renderBoardState(); toast('친구를 찾으면 주변과 다 찬 줄에 × 표시를 해 드려요.'); }
  };
  $('giveupBtn').onclick = () => {
    if (!canPlay()) return;
    const b = $('giveupBtn');
    if (!b.dataset.armed) { b.dataset.armed = '1'; b.lastChild.textContent = '한 번 더 누르면 포기'; setTimeout(() => { delete b.dataset.armed; b.lastChild.textContent = '포기'; }, 2600); return; }
    delete b.dataset.armed; b.lastChild.textContent = '포기';
    lose(true);
  };
  $('copyCode').onclick = () => copyText(Net.code || '', '게임 코드를 복사했어요.');
  $('copyInvite').onclick = () => Native.plugin('Share') && Net.kind === 'p2p'
    ? Native.plugin('Share').share({ title: '숲속 탐정단 초대', text: `숲속 탐정단에서 추리 대결해요! 앱에서 ‘코드로 참가’에 ${Net.code}을 입력하거나 아래 링크를 열어 주세요.`, url: inviteLink(), dialogTitle: '친구 초대하기' }).catch(() => {})
    : Net.kind === 'p2p'
    ? copyText(`숲속 탐정단에서 추리 대결해요! 링크를 열고 이름만 적으면 바로 들어올 수 있어요.\n${inviteLink()}\n(게임 코드: ${Net.code})`, '초대 링크를 복사했어요. 친구에게 보내 주세요!')
    : copyText(`숲속 탐정단에서 추리 대결해요! 이 페이지를 열고 ‘코드로 참가’에 ${Net.code}을 입력해 주세요.`, '초대 문구를 복사했어요. 페이지 링크와 함께 보내 주세요.');
  addEventListener('resize', () => FX.resize());
  matchMedia('(hover: hover)').addEventListener?.('change', renderHowto);
}
function setMode(m) {
  settings.mode = m;
  $('modeMark').setAttribute('aria-pressed', String(m === 'mark'));
  $('modeFind').setAttribute('aria-pressed', String(m === 'find'));
  lastTap = null; renderHowto();
}
async function copyText(text, ok) {
  try { await navigator.clipboard.writeText(text); toast(ok); }
  catch { toast(`복사가 막혀 있어요. 직접 전해 주세요: ${text}`); }
}

/* ---------------- boot ---------------- */
function boot() {
  initNative();
  // the website offers the Android app only to Android phone browsers (never inside the app or on claude.ai)
  if (/Android/i.test(navigator.userAgent) && !Native.is() && !window.claude) $('apkLink').hidden = false;
  Progress.use('guest');
  wire();
  initInput();
  renderHomeStable();
  buildHero();
  Ambient.init();
  const m = /^#room-([a-z2-9]{6})$/i.exec(location.hash || '') || /[?&]room=([a-z2-9]{6})\b/i.exec(location.search || '');
  if (m) { $('joinCode').value = m[1].toUpperCase(); selectTab('Join'); }
  Net.init();
  Account.init();
}
function renderHomeStable() {
  $('animals').innerHTML = ANIMALS.map(a => `<button type="button" class="animal-btn" data-animal="${a.id}" aria-pressed="${a.id === settings.animal}" aria-label="${a.name}">${svgUse('a-' + a.id)}<span>${a.name}</span></button>`).join('');
  $('nameInput').value = settings.name;
  diffCards($('diffs'), settings.diff, pickDiff, false);
  renderOnlineAvailability();
  renderSoloPanel();
}
boot();
})();
