/* Forest Detectives puzzle engine: star-battle style puzzles (k animals per row/col/region, none touching).
   Shared by the offline generator (Node) and the game page. */
(function (root) {
  'use strict';

  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function shuffle(arr, rnd) {
    for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const t = arr[i]; arr[i] = arr[j]; arr[j] = t; }
    return arr;
  }

  /* ---------- geometry ---------- */
  function geom(n, regions) {
    const N = n * n, unitCells = [];
    for (let r = 0; r < n; r++) { const a = []; for (let c = 0; c < n; c++) a.push(r * n + c); unitCells.push(a); }
    for (let c = 0; c < n; c++) { const a = []; for (let r = 0; r < n; r++) a.push(r * n + c); unitCells.push(a); }
    for (let g = 0; g < n; g++) unitCells.push([]);
    for (let i = 0; i < N; i++) unitCells[2 * n + regions[i]].push(i);
    const cellUnits = [], nbrs = [];
    for (let i = 0; i < N; i++) {
      const r = (i / n) | 0, c = i % n;
      cellUnits.push([r, n + c, 2 * n + regions[i]]);
      const a = [];
      for (let dr = -1; dr <= 1; dr++) for (let dc = -1; dc <= 1; dc++) {
        if (!dr && !dc) continue;
        const rr = r + dr, cc = c + dc;
        if (rr >= 0 && rr < n && cc >= 0 && cc < n) a.push(rr * n + cc);
      }
      nbrs.push(a);
    }
    return { n, N, regions, unitCells, cellUnits, nbrs };
  }
  function adjacent(n, a, b) {
    const ra = (a / n) | 0, rb = (b / n) | 0, ca = a % n, cb = b % n;
    return a !== b && Math.abs(ra - rb) <= 1 && Math.abs(ca - cb) <= 1;
  }

  /* ---------- exhaustive solution counter (row by row) ---------- */
  function rowCombos(n, k) {
    const out = [];
    if (k === 1) for (let c = 0; c < n; c++) out.push([c]);
    else for (let a = 0; a < n; a++) for (let b = a + 2; b < n; b++) out.push([a, b]);
    return out;
  }
  function countSolutions(n, k, regions, limit) {
    limit = limit || 2;
    const combos = rowCombos(n, k);
    const colCnt = new Int8Array(n), regCnt = new Int8Array(n);
    const regLeft = [];
    for (let g = 0; g < n; g++) regLeft.push(new Int16Array(n + 1));
    for (let r = n - 1; r >= 0; r--) {
      for (let g = 0; g < n; g++) regLeft[g][r] = regLeft[g][r + 1];
      for (let c = 0; c < n; c++) regLeft[regions[r * n + c]][r]++;
    }
    const sol = new Int16Array(n * k), found = [];
    let count = 0, nodes = 0;
    function rec(r, prev) {
      if (r === n) { count++; if (found.length < limit) found.push(Array.from(sol, (c, i) => ((i / k) | 0) * n + c)); return count >= limit; }
      for (let x = 0; x < combos.length; x++) {
        const cmb = combos[x];
        let ok = true;
        for (let y = 0; y < cmb.length; y++) {
          const c = cmb[y];
          if (colCnt[c] >= k || regCnt[regions[r * n + c]] >= k) { ok = false; break; }
          if (prev) for (let z = 0; z < prev.length; z++) if (Math.abs(prev[z] - c) <= 1) { ok = false; break; }
          if (!ok) break;
        }
        if (!ok) continue;
        if (k === 2 && regions[r * n + cmb[0]] === regions[r * n + cmb[1]] && regCnt[regions[r * n + cmb[0]]] > 0) continue;
        nodes++;
        for (let y = 0; y < cmb.length; y++) { colCnt[cmb[y]]++; regCnt[regions[r * n + cmb[y]]]++; }
        let feasible = true;
        for (let g = 0; g < n && feasible; g++) { const need = k - regCnt[g]; if (need > 0 && regLeft[g][r + 1] < need) feasible = false; }
        if (feasible && k > 1) {
          const m = n - r - 1;
          for (let c = 0; c < n && feasible; c++) {
            const need = k - colCnt[c]; if (need <= 0) continue;
            const cap = cmb.indexOf(c) >= 0 ? Math.floor(m / 2) : Math.ceil(m / 2);
            if (cap < need) feasible = false;
          }
        }
        let stop = false;
        if (feasible) { for (let y = 0; y < k; y++) sol[r * k + y] = cmb[y]; stop = rec(r + 1, cmb); }
        for (let y = 0; y < cmb.length; y++) { colCnt[cmb[y]]--; regCnt[regions[r * n + cmb[y]]]--; }
        if (stop) return true;
      }
      return false;
    }
    rec(0, null);
    return { count, solutions: found, nodes };
  }

  /* ---------- logical solver: technique steps with tiers ---------- */
  // state: Int8Array, 0 unknown, 1 animal, 2 empty
  function Logic(n, k, regions) {
    this.n = n; this.k = k; this.G = geom(n, regions); this.U = 3 * n;
  }
  Logic.prototype.unknowns = function (st, u) { const out = []; const cells = this.G.unitCells[u]; for (let i = 0; i < cells.length; i++) if (st[cells[i]] === 0) out.push(cells[i]); return out; };
  Logic.prototype.need = function (st, u) { let s = 0; const cells = this.G.unitCells[u]; for (let i = 0; i < cells.length; i++) if (st[cells[i]] === 1) s++; return this.k - s; };
  Logic.prototype.canPlace = function (cells, r) {
    if (r <= 0) return true;
    if (cells.length < r) return false;
    if (r === 1) return true;
    const n = this.n;
    if (r === 2) { for (let i = 0; i < cells.length; i++) for (let j = i + 1; j < cells.length; j++) if (!adjacent(n, cells[i], cells[j])) return true; return false; }
    const pick = (start, left, chosen) => {
      if (!left) return true;
      for (let i = start; i < cells.length; i++) {
        if (chosen.some(x => adjacent(n, x, cells[i]))) continue;
        chosen.push(cells[i]); if (pick(i + 1, left - 1, chosen)) return true; chosen.pop();
      }
      return false;
    };
    return pick(0, r, []);
  };
  Logic.prototype.placements = function (cells, r) {
    const n = this.n, out = [];
    if (r === 1) { for (const c of cells) out.push([c]); return out; }
    if (r === 2) { for (let i = 0; i < cells.length; i++) for (let j = i + 1; j < cells.length; j++) if (!adjacent(n, cells[i], cells[j])) out.push([cells[i], cells[j]]); return out; }
    return out;
  };
  // returns unit index that is broken, -1 if fine, -2 if adjacent animals
  Logic.prototype.contradiction = function (st) {
    const G = this.G;
    for (let i = 0; i < G.N; i++) if (st[i] === 1) for (const j of G.nbrs[i]) if (st[j] === 1) return -2;
    for (let u = 0; u < this.U; u++) {
      const need = this.need(st, u);
      if (need < 0) return u;
      if (need > 0 && !this.canPlace(this.unknowns(st, u), need)) return u;
    }
    return -1;
  };
  Logic.prototype.solved = function (st) {
    let s = 0; for (let i = 0; i < st.length; i++) if (st[i] === 1) s++;
    return s === this.n * this.k && this.contradiction(st) === -1;
  };

  Logic.prototype.tier1 = function (st) {
    const G = this.G;
    for (let i = 0; i < G.N; i++) if (st[i] === 1) {
      const elim = G.nbrs[i].filter(j => st[j] === 0);
      if (elim.length) return { tier: 1, kind: 'around', cell: i, place: [], elim, units: [] };
    }
    for (let u = 0; u < this.U; u++) {
      if (this.need(st, u) === 0) { const elim = this.unknowns(st, u); if (elim.length) return { tier: 1, kind: 'full', place: [], elim, units: [u] }; }
    }
    for (let u = 0; u < this.U; u++) {
      const need = this.need(st, u); if (need <= 0) continue;
      const un = this.unknowns(st, u);
      if (un.length === need && this.canPlace(un, need)) return { tier: 1, kind: 'last', place: un, elim: [], units: [u] };
    }
    return null;
  };
  Logic.prototype.tier2 = function (st) {
    const G = this.G, n = this.n, U = this.U;
    // packing inside a unit (only meaningful for k >= 2)
    if (this.k > 1) for (let u = 0; u < U; u++) {
      const need = this.need(st, u); if (need <= 0) continue;
      const un = this.unknowns(st, u), P = this.placements(un, need);
      if (!P.length) continue;
      const cnt = new Map(); for (const p of P) for (const c of p) cnt.set(c, (cnt.get(c) || 0) + 1);
      const place = un.filter(c => cnt.get(c) === P.length), elim = un.filter(c => !cnt.has(c));
      if (place.length) return { tier: 2, kind: 'pack', place, elim: [], units: [u] };
      if (elim.length) return { tier: 2, kind: 'pack', place: [], elim, units: [u] };
    }
    // single-unit confinement
    const typeOf = u => (u / n) | 0;
    for (let a = 0; a < U; a++) {
      const na = this.need(st, a); if (na <= 0) continue;
      const ua = this.unknowns(st, a); if (!ua.length) continue;
      for (let t = 0; t < 3; t++) {
        if (t === typeOf(a)) continue;
        const b = G.cellUnits[ua[0]][t];
        if (!ua.every(c => G.cellUnits[c][t] === b)) continue;
        if (this.need(st, b) !== na) continue;
        const inA = new Set(ua);
        const elim = this.unknowns(st, b).filter(c => !inA.has(c));
        if (elim.length) return { tier: 2, kind: 'confine', place: [], elim, units: [a], via: [b] };
      }
    }
    // one-step: an animal here would leave some unit without room
    const order = this.cellOrder(st);
    for (const c of order) {
      const removed = new Set(G.nbrs[c]); removed.add(c);
      for (const u of G.cellUnits[c]) if (this.need(st, u) === 1) for (const x of G.unitCells[u]) if (st[x] === 0) removed.add(x);
      for (let v = 0; v < U; v++) {
        let need = this.need(st, v); if (G.cellUnits[c].indexOf(v) >= 0) need--;
        if (need <= 0) continue;
        const avail = this.unknowns(st, v).filter(x => !removed.has(x));
        if (!this.canPlace(avail, need)) return { tier: 2, kind: 'blocks', cell: c, place: [], elim: [c], units: [v] };
      }
    }
    return null;
  };
  Logic.prototype.cellOrder = function (st) {
    // cells in tight units first: makes hints feel natural and trial search faster
    const G = this.G, score = [];
    for (let i = 0; i < G.N; i++) if (st[i] === 0) {
      let s = 0; for (const u of G.cellUnits[i]) s += this.unknowns(st, u).length;
      score.push([s, i]);
    }
    score.sort((a, b) => a[0] - b[0] || a[1] - b[1]);
    return score.map(x => x[1]);
  };
  Logic.prototype.tier3 = function (st) {
    const n = this.n, G = this.G;
    const types = [0, 1, 2];
    for (let j = 2; j <= Math.floor(n / 2); j++) {
      for (const ta of types) for (const tb of types) {
        if (ta === tb) continue;
        const pool = [];
        for (let i = 0; i < n; i++) { const u = ta * n + i; if (this.need(st, u) > 0) pool.push(u); }
        if (pool.length <= j) continue;
        const idx = []; let res = null;
        const rec = (start) => {
          if (res) return;
          if (idx.length === j) {
            const X = idx.map(i => pool[i]);
            let needX = 0; const cellsX = new Set(), Y = new Set();
            for (const u of X) { needX += this.need(st, u); for (const c of this.unknowns(st, u)) { cellsX.add(c); Y.add(G.cellUnits[c][tb]); } }
            if (Y.size !== j) return;
            let needY = 0; for (const v of Y) needY += this.need(st, v);
            if (needY !== needX) return;
            const elim = [];
            for (const v of Y) for (const c of this.unknowns(st, v)) if (!cellsX.has(c)) elim.push(c);
            if (elim.length) res = { tier: 3, kind: 'confine', place: [], elim, units: X, via: Array.from(Y) };
            return;
          }
          for (let i = start; i < pool.length; i++) {
            idx.push(i);
            // prune: touched units already exceed j
            const touched = new Set();
            for (const q of idx) for (const c of this.unknowns(st, pool[q])) touched.add(G.cellUnits[c][tb]);
            if (touched.size <= j) rec(i + 1);
            idx.pop(); if (res) return;
          }
        };
        rec(0);
        if (res) return res;
      }
    }
    return null;
  };
  Logic.prototype.propagate = function (st, maxTier) {
    // apply tier1/tier2 steps until stuck; returns contradiction unit (>=0 or -2) or -1
    for (let guard = 0; guard < 400; guard++) {
      const bad = this.contradiction(st); if (bad !== -1) return bad;
      const step = this.tier1(st) || (maxTier >= 2 ? this.tier2(st) : null);
      if (!step) return -1;
      for (const c of step.place) st[c] = 1;
      for (const c of step.elim) st[c] = 2;
    }
    return -1;
  };
  Logic.prototype.tier4 = function (st) {
    const order = this.cellOrder(st);
    for (const c of order) {
      const t = Int8Array.from(st); t[c] = 1;
      const bad = this.propagate(t, 2);
      if (bad !== -1) return { tier: 4, kind: 'trial', cell: c, place: [], elim: [c], units: bad >= 0 ? [bad] : [] };
    }
    return null;
  };
  Logic.prototype.next = function (st, maxTier) {
    maxTier = maxTier || 4;
    return this.tier1(st) || (maxTier >= 2 && this.tier2(st)) || (maxTier >= 3 && this.tier3(st)) || (maxTier >= 4 && this.tier4(st)) || null;
  };
  Logic.prototype.grade = function (maxTier) {
    const st = new Int8Array(this.G.N), tiers = [0, 0, 0, 0, 0];
    let steps = 0;
    for (;;) {
      if (this.solved(st)) break;
      const s = this.next(st, maxTier);
      if (!s) break;
      for (const c of s.place) st[c] = 1;
      for (const c of s.elim) st[c] = 2;
      tiers[s.tier]++; steps++;
      if (this.contradiction(st) !== -1) return { solved: false, broken: true, tiers, steps };
    }
    const solved = this.solved(st);
    let maxT = 0; for (let t = 1; t < 5; t++) if (tiers[t]) maxT = t;
    return { solved, tiers, steps, maxTier: maxT };
  };

  /* ---------- generator ---------- */
  function randomSolution(n, k, rnd) {
    const combos = rowCombos(n, k), colCnt = new Int8Array(n), rows = [];
    function rec(r, prev) {
      if (r === n) return true;
      const order = shuffle(combos.slice(), rnd);
      for (const cmb of order) {
        if (cmb.some(c => colCnt[c] >= k)) continue;
        if (prev && cmb.some(c => prev.some(p => Math.abs(p - c) <= 1))) continue;
        cmb.forEach(c => colCnt[c]++);
        const m = n - r - 1;
        let ok = true;
        for (let c = 0; c < n && ok; c++) { const need = k - colCnt[c]; const cap = cmb.indexOf(c) >= 0 ? Math.floor(m / 2) : Math.ceil(m / 2); if (need > cap) ok = false; }
        if (ok) { rows[r] = cmb; if (rec(r + 1, cmb)) return true; }
        cmb.forEach(c => colCnt[c]--);
      }
      return false;
    }
    rec(0, null);
    const cells = [];
    rows.forEach((cmb, r) => cmb.forEach(c => cells.push(r * n + c)));
    return cells;
  }
  function orthNbrs(n, i) {
    const r = (i / n) | 0, c = i % n, a = [];
    if (r > 0) a.push(i - n); if (r < n - 1) a.push(i + n); if (c > 0) a.push(i - 1); if (c < n - 1) a.push(i + 1);
    return a;
  }
  function growBlobs(n, seeds, rnd) {
    const N = n * n, owner = new Int16Array(N).fill(-1);
    seeds.forEach((s, b) => { owner[s] = b; });
    let frontier = [];
    seeds.forEach((s, b) => orthNbrs(n, s).forEach(x => frontier.push([x, b])));
    let left = N - seeds.length;
    while (left > 0 && frontier.length) {
      const idx = Math.floor(rnd() * frontier.length);
      const [x, b] = frontier[idx];
      frontier[idx] = frontier[frontier.length - 1]; frontier.pop();
      if (owner[x] !== -1) continue;
      owner[x] = b; left--;
      orthNbrs(n, x).forEach(y => { if (owner[y] === -1) frontier.push([y, b]); });
    }
    return owner;
  }
  function pairBlobs(n, owner, count, rnd) {
    const adj = []; for (let b = 0; b < count; b++) adj.push(new Set());
    for (let i = 0; i < n * n; i++) for (const j of orthNbrs(n, i)) if (owner[i] !== owner[j]) adj[owner[i]].add(owner[j]);
    const mate = new Int16Array(count).fill(-1);
    let budget = 20000;
    function rec() {
      if (--budget < 0) return false;
      let best = -1, bestOpts = null;
      for (let b = 0; b < count; b++) if (mate[b] === -1) {
        const opts = Array.from(adj[b]).filter(x => mate[x] === -1);
        if (!opts.length) return false;
        if (!bestOpts || opts.length < bestOpts.length) { best = b; bestOpts = opts; }
      }
      if (best === -1) return true;
      for (const o of shuffle(bestOpts, rnd)) { mate[best] = o; mate[o] = best; if (rec()) return true; mate[best] = -1; mate[o] = -1; }
      return false;
    }
    if (!rec()) return null;
    const regionOf = new Int16Array(count).fill(-1); let g = 0;
    for (let b = 0; b < count; b++) if (regionOf[b] === -1) { regionOf[b] = g; regionOf[mate[b]] = g; g++; }
    return Array.from(owner, b => regionOf[b]);
  }
  function connectedWithout(n, regions, g, skip) {
    const cells = []; for (let i = 0; i < n * n; i++) if (regions[i] === g && i !== skip) cells.push(i);
    if (!cells.length) return false;
    const seen = new Set([cells[0]]), q = [cells[0]];
    while (q.length) { const x = q.pop(); for (const y of orthNbrs(n, x)) if (y !== skip && regions[y] === g && !seen.has(y)) { seen.add(y); q.push(y); } }
    return seen.size === cells.length;
  }
  function makeUnique(n, k, regions, solution, rnd, maxIter) {
    const isStar = new Set(solution);
    for (let it = 0; it < maxIter; it++) {
      const res = countSolutions(n, k, regions, 2);
      if (res.count === 1) return true;
      if (res.count === 0) return false;
      const alt = res.solutions.find(s => s.some(c => !isStar.has(c)));
      const diff = shuffle(alt.filter(c => !isStar.has(c)), rnd);
      let moved = false;
      for (const d of diff) {
        const g = regions[d];
        if (!connectedWithout(n, regions, g, d)) continue;
        const opts = shuffle(Array.from(new Set(orthNbrs(n, d).map(x => regions[x]).filter(x => x !== g))), rnd);
        if (!opts.length) continue;
        regions[d] = opts[0]; moved = true; break;
      }
      if (!moved) return false;
    }
    return false;
  }
  function generate(n, k, rnd) {
    for (let attempt = 0; attempt < 200; attempt++) {
      const solution = randomSolution(n, k, rnd);
      let regions;
      if (k === 1) regions = Array.from(growBlobs(n, solution, rnd));
      else { const owner = growBlobs(n, solution, rnd); regions = pairBlobs(n, owner, solution.length, rnd); if (!regions) continue; }
      if (makeUnique(n, k, regions, solution, rnd, 60)) return { n, k, regions, solution: solution.slice().sort((a, b) => a - b) };
    }
    return null;
  }

  /* ---------- transforms + codec ---------- */
  function transformCell(n, i, t) {
    let r = (i / n) | 0, c = i % n;
    if (t & 4) { const x = r; r = c; c = x; }
    if (t & 1) c = n - 1 - c;
    if (t & 2) r = n - 1 - r;
    return r * n + c;
  }
  function transformPuzzle(p, t) {
    const n = p.n, regions = new Array(n * n);
    for (let i = 0; i < n * n; i++) regions[transformCell(n, i, t)] = p.regions[i];
    // relabel regions in reading order so labels are stable
    const map = new Map(); let g = 0;
    const out = regions.map(x => { if (!map.has(x)) map.set(x, g++); return map.get(x); });
    return { n, k: p.k, regions: out, solution: p.solution.map(i => transformCell(n, i, t)).sort((a, b) => a - b) };
  }
  const B36 = '0123456789abcdefghijklmnopqrstuvwxyz';
  function encode(p) { return p.regions.map(x => B36[x]).join('') + '|' + p.solution.map(i => B36[(i / p.n) | 0] + B36[i % p.n]).join(''); }
  function decode(n, k, s) {
    const [r, sol] = s.split('|');
    const regions = Array.from(r, ch => B36.indexOf(ch)), solution = [];
    for (let i = 0; i < sol.length; i += 2) solution.push(B36.indexOf(sol[i]) * n + B36.indexOf(sol[i + 1]));
    return { n, k, regions, solution };
  }

  const api = { mulberry32, shuffle, geom, adjacent, countSolutions, Logic, generate, transformPuzzle, encode, decode, randomSolution };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.ForestEngine = api;
})(typeof self !== 'undefined' ? self : this);
