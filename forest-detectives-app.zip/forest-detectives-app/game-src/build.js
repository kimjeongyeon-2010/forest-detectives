// Builds three versions of 숲속 탐정단 from the same source files in this folder:
//  1. claude.ai artifact   -> /home/user/forest-detectives/index.html            (online rooms via the platform's live room)
//  2. website (GitHub)     -> /home/user/forest-detectives-site/index.html       (P2P online rooms, Firebase from Google's CDN)
//  3. Android/iOS app      -> ../www/index.html (+ fonts/)                       (P2P rooms, Firebase + fonts bundled for offline use)
const fs = require('fs');
const path = require('path');
const dir = __dirname, appRoot = path.join(dir, '..');
const read = f => fs.readFileSync(path.join(dir, f), 'utf8');
const engine = read('engine.js'), bank = read('bank.json'), stages = read('stages.json'), p2p = read('trystero.bundle.js');
const firebaseCfg = fs.existsSync(path.join(dir, 'firebase-config.json')) ? JSON.stringify(JSON.parse(read('firebase-config.json'))) : 'null';
const app = read('app.js').replace('/*__BANK__*/null', () => bank).replace('/*__STAGES__*/null', () => stages).replace('/*__FIREBASE__*/null', () => firebaseCfg);
const tpl = read('template.html');
const write = (file, text) => { fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, text); return text.length; };

// 1. claude.ai artifact (no P2P bundle, no Firebase: the artifact sandbox can't reach either)
const artifact = tpl.replace('/*__ENGINE__*/', () => engine).replace('/*__APP__*/', () => app);
const sizes = { artifact: write('/home/user/forest-detectives/index.html', artifact) };

// 2 + 3 share a full-document wrapper
const split = tpl.indexOf('<svg width="0" height="0"');
const headPart = tpl.slice(0, split).replace('<meta name="claude:viewport-fit-sides" content="cover">\n', '');
const bodyPart = extra => tpl.slice(split)
  .replace('<script>\n/*__ENGINE__*/\n</script>', () => `<script>\n/* Trystero 0.26.0 (MIT) with @noble/secp256k1 (MIT), bundled */\n${p2p}\n</script>\n${extra}<script>\n${engine}\n</script>`)
  .replace('/*__APP__*/', () => app);
const icon = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'%3E%3Ctext y='.9em' font-size='90'%3E%F0%9F%A6%8A%3C/text%3E%3C/svg%3E";
const doc = (head, body) => `<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="description" content="색깔 구역마다 숨은 숲속 친구를 논리로 찾아내는 추리 퍼즐. 스테이지 500개, 친구와 온라인 레이스.">
<meta property="og:title" content="숲속 탐정단">
<meta property="og:description" content="누가 먼저 숲속 친구를 찾아낼까요? 친구와 같은 퍼즐로 추리 대결!">
<meta name="theme-color" content="#245c47">
<link rel="icon" href="${icon}">
<style>:root{color-scheme:light;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px)}body{margin:0;font:14px system-ui}img{max-width:100%}[hidden]{display:none!important}</style>
${head}</head>
<body>
${body}</body>
</html>
`;

// 2. website
const website = doc(headPart, bodyPart(''));
sizes.website = write('/home/user/forest-detectives-site/index.html', website);
write('/home/user/forest-detectives/forest-detectives-online.html', website);

// 3. native app: local fonts, bundled Firebase, Capacitor safe-area variables (older Android WebViews)
const www = path.join(appRoot, 'www');
const fontsOut = path.join(www, 'fonts');
fs.rmSync(fontsOut, { recursive: true, force: true }); fs.mkdirSync(fontsOut, { recursive: true });
let fontCss = '';
for (const [pkg, css] of [['jua', '400.css'], ['gowun-dodum', '400.css'], ['dm-mono', '500.css']]) {
  const pdir = path.join(appRoot, 'node_modules/@fontsource', pkg);
  const text = fs.readFileSync(path.join(pdir, css), 'utf8')
    .replace(/, url\(\.\/files\/[^)]+\.woff\) format\('woff'\)/g, '')
    .replace(/url\(\.\/files\/([^)]+\.woff2)\)/g, (_, f) => { fs.copyFileSync(path.join(pdir, 'files', f), path.join(fontsOut, f)); return `url(${f})`; });
  fontCss += text + '\n';
  fs.copyFileSync(path.join(pdir, 'LICENSE'), path.join(fontsOut, `LICENSE-${pkg}.txt`));
}
write(path.join(fontsOut, 'fonts.css'), fontCss);
const appHead = headPart
  .replace(/<link rel="preconnect"[^>]*>\n/g, '')
  .replace(/<link rel="stylesheet" href="https:\/\/fonts\.googleapis\.com[^>]*>/, '<link rel="stylesheet" href="fonts/fonts.css">');
const firebaseBundle = `<script>\n/* Firebase JS SDK 12.19.0 (Apache-2.0), bundled */\n${read('firebase.bundle.js')}\n</script>\n`;
const safe = s => s.replace(/env\(safe-area-inset-(top|right|bottom|left),\s*0px\)/g, (_, side) => `var(--safe-area-inset-${side},env(safe-area-inset-${side},0px))`);
const appHtml = safe(doc(appHead, bodyPart(firebaseBundle)));
if (appHtml.includes('fonts.googleapis.com')) throw new Error('app build still loads Google Fonts from the web');
sizes.app = write(path.join(www, 'index.html'), appHtml);
console.log(Object.entries(sizes).map(([k, v]) => `${k} ${(v / 1024).toFixed(0)}KB`).join(' | '), '| firebase', firebaseCfg === 'null' ? 'not configured' : 'configured');
