// 500 stages that get steadily harder: board size grows by chapter, and inside each chapter
// puzzles are ordered by how much advanced deduction they need (graded by the logic solver).
const fs = require('fs');
const E = require('./engine.js');
const CHAPTERS = [
  { from: 1,   to: 20,  n: 5,  pool: 60,  ok: g => g.maxTier <= 2 },
  { from: 21,  to: 60,  n: 6,  pool: 120, ok: g => g.maxTier <= 2 },
  { from: 61,  to: 120, n: 7,  pool: 150, ok: g => g.maxTier <= 2 },
  { from: 121, to: 200, n: 8,  pool: 200, ok: g => g.maxTier <= 3 },
  { from: 201, to: 300, n: 9,  pool: 220, ok: g => g.maxTier >= 2 && g.tiers[4] <= 1 },
  { from: 301, to: 400, n: 10, pool: 200, ok: g => g.maxTier >= 3 && g.tiers[4] <= 1 },
  { from: 401, to: 500, n: 10, pool: 220, ok: g => g.tiers[4] >= 1 && g.tiers[3] + g.tiers[4] >= 3 },
];
const score = g => g.tiers[1] * 0.05 + g.tiers[2] + g.tiers[3] * 5 + g.tiers[4] * 12;
const stages = [], seen = new Set(), report = [];
for (const ch of CHAPTERS) {
  const need = ch.to - ch.from + 1, rnd = E.mulberry32(9000 + ch.from), pool = [];
  let tries = 0; const t0 = Date.now();
  while (pool.length < ch.pool && tries < ch.pool * 60) {
    tries++;
    const p = E.generate(ch.n, 1, rnd); if (!p) continue;
    const sizes = Array.from({ length: ch.n }, (_, x) => p.regions.filter(r => r === x).length);
    if (Math.max(...sizes) > ch.n * ch.n / ch.n * 2.8) continue;
    const g = new E.Logic(ch.n, 1, p.regions).grade(4);
    if (!g.solved || !ch.ok(g)) continue;
    const code = E.encode(E.transformPuzzle(p, 0));
    if (seen.has(code)) continue; seen.add(code);
    pool.push({ code, s: score(g), t: g.tiers });
  }
  pool.sort((a, b) => a.s - b.s);
  // evenly spaced picks across the sorted pool, so difficulty climbs smoothly through the chapter
  const picks = [];
  for (let i = 0; i < need; i++) picks.push(pool[Math.round(i * (pool.length - 1) / Math.max(1, need - 1))]);
  picks.forEach(x => stages.push(x.code));
  report.push(`${ch.from}-${ch.to} ${ch.n}x${ch.n}: pool ${pool.length}/${tries} tries, score ${picks[0].s.toFixed(1)} -> ${picks[need - 1].s.toFixed(1)}, ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  if (picks.some(x => !x)) throw new Error('pool too small for chapter ' + ch.from);
}
let bad = 0;
stages.forEach(s => { const n = Math.sqrt(s.indexOf('|')); const q = E.decode(n, 1, s); const r = E.countSolutions(n, 1, q.regions, 2); if (r.count !== 1 || r.solutions[0].join() !== q.solution.join()) bad++; });
fs.writeFileSync(__dirname + '/stages.json', JSON.stringify(stages));
console.log(report.join('\n'));
console.log('stages', stages.length, 'unique-solution check failures', bad, 'bytes', JSON.stringify(stages).length);
